// 魔方财务系统 v3 供应商插件（zjmf_api 下游接口）
//
// 上游约定：
// - HTTP 状态恒为 200，业务码在 body.status：200 成功；1001 支付完成或 0 元单开通成功（带 data.hostid）；
//   400 / 406 业务失败（406 有时为字符串 "406"）；405 未登录或令牌失效；503 维护中；
// - 请求体为 application/x-www-form-urlencoded，数组写作 cart_data[configoptions][12]=34。
//
// 下单沿用官方 createFinal 顺序：读取币种 → 清空购物车（按 downstream_token 做幂等检查）→ 结算 → 余额支付，
// 每完成一步写入检查点；开通后把 ctx.service.reference 写入产品备注，便于按备注反查。
// 插件不保存任何状态，跨调用的信息只通过检查点与 novaix.cache 传递。

var PAGE_SIZE = 20;
var JWT_TTL = 7000; // 上游 JWT 有效期 7200 秒，提前失效
var LIST_TTL = 300;
var MAX_SCAN_PAGES = 20;

// 本地周期未配置上游周期时的默认映射
var DEFAULT_CYCLES = { monthly: "monthly", quarterly: "quarterly", yearly: "annually" };

var CYCLE_LABELS = {
  free: "免费",
  onetime: "一次性",
  hour: "按小时",
  day: "按天",
  monthly: "月付",
  quarterly: "季付",
  semiannually: "半年付",
  annually: "年付",
  biennially: "两年付",
  triennially: "三年付",
  fourly: "四年付",
  fively: "五年付",
  sixly: "六年付",
  sevenly: "七年付",
  eightly: "八年付",
  ninely: "九年付",
  tenly: "十年付"
};

// 本地操作名 → 上游模块函数
var ACTION_FUNCS = {
  on: "on",
  off: "off",
  reboot: "reboot",
  hard_off: "hard_off",
  hard_reboot: "hard_reboot",
  reset_password: "crack_pass",
  reinstall: "reinstall"
};

var ACTION_LABELS = {
  on: "开机",
  off: "关机",
  reboot: "重启",
  hard_off: "强制关机",
  hard_reboot: "强制重启",
  reset_password: "重置密码",
  reinstall: "重装系统"
};

// 独立服务器（dcim）类型产品的操作接口
var DCIM_PATHS = {
  on: "/dcim/on",
  off: "/dcim/off",
  reboot: "/dcim/reboot",
  vnc: "/dcim/novnc",
  crack_pass: "/dcim/crack_pass",
  reinstall: "/dcim/reinstall"
};

// ---------- 通用工具 ----------

function str(v) {
  return v === undefined || v === null ? "" : String(v);
}

function num(v) {
  var n = Number(v);
  return isFinite(n) ? n : 0;
}

// 上游金额（元）转为分
function toCents(v) {
  var n = parseFloat(v);
  return isFinite(n) ? Math.round(n * 100) : 0;
}

function yuan(cents) {
  return (cents / 100).toFixed(2);
}

function nowUnix() {
  return Math.floor(Date.now() / 1000);
}

function assign(target, extra) {
  if (extra) {
    for (var k in extra) {
      if (extra[k] !== undefined) target[k] = extra[k];
    }
  }
  return target;
}

// 编码为 PHP 风格的 form-urlencoded：对象展开为 key[sub]=v，数组展开为 key[]=v
function encodeForm(params) {
  var parts = [];
  function add(key, v) {
    if (v === undefined || v === null) return;
    if (Array.isArray(v)) {
      for (var i = 0; i < v.length; i++) add(key + "[]", v[i]);
      return;
    }
    if (typeof v === "object") {
      for (var k in v) add(key + "[" + k + "]", v[k]);
      return;
    }
    parts.push(url.encode(key) + "=" + url.encode(String(v)));
  }
  for (var k in params) add(k, params[k]);
  return parts.join("&");
}

// keyvalue 字段的值为 JSON 对象字符串
function parseKeyValue(raw) {
  if (!raw) return {};
  if (typeof raw === "object") return raw;
  try {
    var v = JSON.parse(raw);
    return v && typeof v === "object" && !Array.isArray(v) ? v : {};
  } catch (e) {
    return {};
  }
}

function randomPassword() {
  return "Nv" + crypto.randomHex(5) + "Q" + crypto.randomHex(3);
}

// 上游返回的 hostid 可能是数字、字符串或数组
function firstId(v) {
  if (Array.isArray(v)) return v.length ? str(v[0]) : "";
  return str(v);
}

// 一次返回全量的列表：本地按关键字过滤并分页
function localPage(items, page, keyword) {
  var kw = str(keyword).trim().toLowerCase();
  var list = items;
  if (kw) {
    list = [];
    for (var i = 0; i < items.length; i++) {
      var text = (items[i].label + " " + str(items[i].description) + " " + items[i].value).toLowerCase();
      if (text.indexOf(kw) >= 0) list.push(items[i]);
    }
  }
  var start = (page - 1) * PAGE_SIZE;
  return { items: list.slice(start, start + PAGE_SIZE), has_more: start + PAGE_SIZE < list.length };
}

// ---------- 结果构造 ----------

function upstreamError(code, message) {
  var e = new Error(message);
  e.code = code;
  return e;
}

function errorMessage(e) {
  if (!e) return "未知错误";
  return str(e.message) || String(e);
}

function errorCode(e) {
  if (e && typeof e.code === "string" && e.code) return e.code;
  return /timeout|deadline|超时/i.test(errorMessage(e)) ? "timeout" : "upstream_error";
}

function succeeded(extra) {
  return assign({ status: "succeeded" }, extra);
}

function pending(retryAfter, extra) {
  return assign({ status: "pending", retry_after: retryAfter }, extra);
}

function failed(code, message, retryable, extra) {
  return assign({ status: "failed", error: { code: code, message: message, retryable: !!retryable } }, extra);
}

function unknown(code, message, extra) {
  return assign({ status: "unknown", error: { code: code, message: message } }, extra);
}

function unknownFrom(e, extra) {
  return unknown(errorCode(e), "上游结果未知：" + errorMessage(e), extra);
}

// 调用尚未产生副作用时出错：可安全重试（鉴权与参数错误除外）
function failedBeforeSubmit(e) {
  var code = errorCode(e);
  return failed(code, "调用上游失败：" + errorMessage(e), code !== "auth" && code !== "invalid_params");
}

// 按上游提示归类错误码
function classify(resp) {
  var msg = str(resp && resp.msg);
  var status = resp ? resp.status : 0;
  if (status === 404) return "unsupported";
  if (status === 401 || status === 405) return "auth";
  if (status === 503) return "rate_limited";
  if (/余额不足|余额不够|insufficient/i.test(msg)) return "insufficient_balance";
  if (/库存|售罄|缺货|sold\s*out/i.test(msg)) return "out_of_stock";
  if (/重复|频繁|稍后再试|too\s*many/i.test(msg)) return "rate_limited";
  return "upstream_error";
}

// 上游明确拒绝：重复提交或维护时前一次请求可能已执行，按结果未知处理
function rejected(resp, prefix, extra) {
  var code = classify(resp);
  if (code === "rate_limited") return unknown(code, prefix + "，上游暂时无法处理，结果未知：" + resp.msg, extra);
  return failed(code, prefix + "：" + resp.msg, false, extra);
}

// 支付成功：1001，或 406 + PayStatus=Paid（账单此前已支付）
function isPaid(resp) {
  if (resp.status === 1001) return true;
  var d = resp.data || {};
  if (str(d.PayStatus || d.pay_status) === "Paid") return true;
  return /已支付|已付款/.test(resp.msg) && !/未支付/.test(resp.msg);
}

// ---------- HTTP 与鉴权 ----------

function baseURL(ctx) {
  var u = str(ctx.connection && ctx.connection.url).trim().replace(/\/+$/, "");
  if (!/^https?:\/\//i.test(u)) throw upstreamError("invalid_params", "接口地址必须以 http:// 或 https:// 开头");
  return u;
}

// 令牌缓存键包含账号与密钥摘要：修改连接配置后不会复用旧令牌
function tokenKey(ctx) {
  var user = str(ctx.connection.username).trim().toLowerCase();
  return "jwt:" + user + "@" + baseURL(ctx) + "#" + crypto.sha256(user + "\n" + str(ctx.connection.api_key)).slice(0, 16);
}

function send(ctx, method, path, params, token) {
  var target = baseURL(ctx) + path;
  var headers = { Accept: "application/json" };
  if (token) headers.Authorization = "Bearer " + token;
  var form = encodeForm(params || {});
  var body;
  if (method === "GET") {
    if (form) target += (target.indexOf("?") >= 0 ? "&" : "?") + form;
  } else {
    body = form;
    headers["Content-Type"] = "application/x-www-form-urlencoded";
  }
  var resp = http.request(method, target, { headers: headers, body: body, timeout: 30 });
  if (resp.status === 401) return { status: 401, msg: "未授权" };
  if (resp.status === 404) return { status: 404, msg: "上游接口不存在（HTTP 404）" };
  if (resp.status >= 500) throw upstreamError("upstream_error", "上游服务异常（HTTP " + resp.status + "）");
  var data;
  try {
    data = JSON.parse(resp.body);
  } catch (e) {
    throw upstreamError("upstream_error", "上游返回了无法解析的响应（HTTP " + resp.status + "）");
  }
  if (!data || typeof data !== "object") throw upstreamError("upstream_error", "上游响应格式错误");
  data.status = Number(data.status);
  data.msg = str(data.msg || data.message);
  return data;
}

function login(ctx) {
  var user = str(ctx.connection.username).trim();
  var key = str(ctx.connection.api_key);
  if (!user || !key) throw upstreamError("auth", "请填写上游账号与 API 密钥");
  var resp = send(ctx, "POST", "/zjmf_api_login", { username: user, password: key }, "");
  var jwt = resp.jwt || (resp.data && resp.data.jwt);
  if (resp.status !== 200 || !jwt) throw upstreamError("auth", "上游登录失败：" + (resp.msg || "未返回令牌"));
  novaix.cache.set(tokenKey(ctx), String(jwt), JWT_TTL);
  return String(jwt);
}

function currentToken(ctx) {
  var t = novaix.cache.get(tokenKey(ctx));
  return t ? String(t) : login(ctx);
}

function isAuthFail(resp) {
  return resp.status === 405 || resp.status === 401;
}

// 带鉴权的请求：遇到 405/401 清除缓存的令牌并重新登录一次（未登录时请求未被执行，可安全重发）
function api(ctx, method, path, params) {
  var resp = send(ctx, method, path, params, currentToken(ctx));
  if (isAuthFail(resp)) {
    novaix.cache.delete(tokenKey(ctx));
    resp = send(ctx, method, path, params, login(ctx));
    if (isAuthFail(resp)) throw upstreamError("auth", "上游鉴权失败：" + resp.msg);
  }
  return resp;
}

// ---------- 上下文 ----------

function svc(ctx) {
  return ctx.service || {};
}

function opInfo(ctx) {
  return ctx.operation || {};
}

function checkpointOf(ctx) {
  var cp = ctx.operation && ctx.operation.checkpoint;
  return cp && typeof cp === "object" ? JSON.parse(JSON.stringify(cp)) : {};
}

function saveCheckpoint(ctx, cp) {
  novaix.checkpoint(cp);
  if (ctx.operation) ctx.operation.checkpoint = cp;
}

function hostIdOf(ctx) {
  var id = str(svc(ctx).remote_id).trim();
  return /^\d+$/.test(id) ? id : "";
}

function productIdOf(ctx) {
  var id = str(ctx.product && ctx.product.product_id).trim();
  return /^\d+$/.test(id) ? id : "";
}

function siteURL(ctx) {
  var u = str(ctx.site && ctx.site.url).trim().replace(/\/+$/, "");
  return /^https?:\/\//i.test(u) ? u : "http://localhost";
}

function downstreamParams(ctx) {
  return { downstream_token: svc(ctx).reference, downstream_id: svc(ctx).id, downstream_url: siteURL(ctx) };
}

function identityError(ctx) {
  var s = svc(ctx);
  if (!/^[0-9a-f]{32}$/.test(str(s.reference))) return "服务引用无效（应为 32 位小写十六进制）";
  if (!(Number(s.id) > 0)) return "服务 ID 无效";
  return "";
}

// ---------- 商品与选项 ----------

function cached(key, loader) {
  var v = novaix.cache.get(key);
  if (v !== null && v !== undefined) return v;
  v = loader();
  novaix.cache.set(key, v, LIST_TTL);
  return v;
}

function allProducts(ctx) {
  return cached("products", function () {
    var resp = api(ctx, "GET", "/cart/all");
    if (resp.status !== 200) throw upstreamError(classify(resp), "获取上游商品失败：" + resp.msg);
    var groups = (resp.data && resp.data.products) || resp.products || [];
    var items = [];
    for (var i = 0; i < groups.length; i++) {
      var list = groups[i].products || [];
      for (var j = 0; j < list.length; j++) {
        items.push({ value: str(list[j].id), label: str(list[j].name) || "商品 " + list[j].id, description: str(groups[i].name) });
      }
    }
    return items;
  });
}

function productConfig(ctx, pid) {
  return cached("config:" + pid, function () {
    var resp = api(ctx, "GET", "/cart/get_product_config", { pid: pid });
    if (resp.status !== 200) throw upstreamError(classify(resp), "获取上游商品配置失败：" + resp.msg);
    return resp.data || {};
  });
}

// 周期价格：兼容对象（周期 → 价格）与数组两种格式，价格小于 0 表示不可购买
function pricingList(cfg) {
  var p = cfg.product_pricings || cfg.pricings || (cfg.product && cfg.product.pricings) || {};
  var out = [];
  var i;
  if (Array.isArray(p)) {
    for (i = 0; i < p.length; i++) {
      var cycle = str(p[i].billingcycle || p[i].cycle);
      var price = p[i].price !== undefined ? p[i].price : p[i].product_price !== undefined ? p[i].product_price : p[i].amount;
      if (CYCLE_LABELS[cycle] && parseFloat(price) >= 0) out.push({ cycle: cycle, price: str(price) });
    }
  } else {
    for (var k in p) {
      if (CYCLE_LABELS[k] && parseFloat(p[k]) >= 0) out.push({ cycle: k, price: str(p[k]) });
    }
  }
  return out;
}

// 操作系统选项：来自 option_type=5 的配置项，值为"配置项ID:子项ID"
function osOptions(cfg) {
  var groups = cfg.config_groups || cfg.configoptions || [];
  var items = [];
  for (var i = 0; i < groups.length; i++) {
    var options = groups[i].options || [];
    for (var j = 0; j < options.length; j++) {
      var opt = options[j];
      if (Number(opt.option_type) !== 5) continue;
      var subs = opt.sub || [];
      for (var k = 0; k < subs.length; k++) {
        items.push({ value: str(opt.id) + ":" + str(subs[k].id), label: str(subs[k].option_name), description: str(opt.option_name) });
      }
    }
  }
  return items;
}

function getOptions(ctx, fieldKey, values, opts) {
  values = values || {};
  var page = Math.max(1, parseInt(opts && opts.page, 10) || 1);
  var keyword = str(opts && opts.keyword).trim();
  if (fieldKey === "product_id") return localPage(allProducts(ctx), page, keyword);
  var pid = str(values.product_id).trim();
  if (!/^\d+$/.test(pid)) return { items: [], has_more: false };
  var cfg = productConfig(ctx, pid);
  if (fieldKey === "os") return localPage(osOptions(cfg), page, keyword);
  if (fieldKey === "cycle_monthly" || fieldKey === "cycle_quarterly" || fieldKey === "cycle_yearly") {
    var list = pricingList(cfg);
    var items = [];
    for (var i = 0; i < list.length; i++) {
      items.push({ value: list[i].cycle, label: CYCLE_LABELS[list[i].cycle] + "（¥" + list[i].price + "）", description: list[i].cycle });
    }
    return localPage(items, page, keyword);
  }
  return { items: [], has_more: false };
}

function resolveCycle(ctx) {
  var v = str(svc(ctx).cycle_param).trim();
  if (v) return v;
  v = DEFAULT_CYCLES[str(svc(ctx).billing_cycle)];
  if (v) return v;
  throw upstreamError("invalid_params", "商品未配置该计费周期对应的上游周期");
}

function currencyId(ctx) {
  var resp = api(ctx, "GET", "/user_info");
  if (resp.status !== 200) throw upstreamError(classify(resp), "获取上游账户信息失败：" + resp.msg);
  var user = resp.user || (resp.data && resp.data.user) || {};
  var c = user.currency;
  if (c && typeof c === "object") c = c.id;
  return str(c || user.currencyid);
}

function cartData(ctx, currency) {
  var p = ctx.product || {};
  var pid = productIdOf(ctx);
  if (!pid) throw upstreamError("invalid_params", "商品未配置上游商品");
  var options = {};
  var extra = parseKeyValue(p.config_options);
  for (var k in extra) options[k] = extra[k];
  var os = str(p.os).split(":");
  if (os.length === 2 && os[0] && os[1]) options[os[0]] = os[1];
  var data = {
    pid: pid,
    billingcycle: resolveCycle(ctx),
    configoptions: options,
    customfield: parseKeyValue(p.custom_fields),
    password: str(svc(ctx).checkout && svc(ctx).checkout.password) || randomPassword()
  };
  if (currency) data.currencyid = currency;
  return data;
}

// ---------- 产品 ----------

function isGone(status) {
  return status === "Deleted" || status === "Cancelled" || status === "Terminated";
}

function dueOf(hd) {
  var t = num(hd && hd.nextduedate);
  return t > 0 ? t : undefined;
}

// 产品详情（host_data、module_button、cloud_os），产品不存在时返回 null
function header(ctx, hostId) {
  var resp = api(ctx, "GET", "/host/header", { host_id: hostId });
  if (resp.status === 200 && resp.data && resp.data.host_data) return resp.data;
  if (resp.status === 404 || /不存在|未找到|not\s*found/i.test(resp.msg)) return null;
  throw upstreamError(classify(resp), "查询上游产品失败：" + resp.msg);
}

function pushField(fields, key, label, value, copyable) {
  var v = str(value).trim();
  if (v && v !== "0") fields.push({ key: key, label: label, value: v, copyable: !!copyable });
}

function hostInfo(hd) {
  var ipv6 = "";
  var assigned = str(hd.assignedips).split(/[\s,;]+/);
  for (var i = 0; i < assigned.length; i++) {
    if (assigned[i].indexOf(":") >= 0) {
      ipv6 = assigned[i];
      break;
    }
  }
  var fields = [];
  pushField(fields, "ip", "IP 地址", hd.dedicatedip, true);
  pushField(fields, "ipv6", "IPv6 地址", ipv6, true);
  pushField(fields, "port", "远程端口", hd.port, false);
  pushField(fields, "username", "用户名", hd.username, true);
  pushField(fields, "os", "操作系统", hd.os, false);
  pushField(fields, "hostname", "主机名", hd.domain, false);
  var out = { fields: fields };
  if (str(hd.password)) out.secrets = { password: str(hd.password) };
  return out;
}

function hostResult(hostId, hdr, cp) {
  var hd = hdr.host_data || {};
  var extra = { remote_id: str(hostId), data: { host_type: str(hd.type) } };
  if (cp.invoice_id) extra.remote_ref = str(cp.invoice_id);
  var st = str(hd.domainstatus);
  if (st === "Active" || st === "Suspended") {
    var info = hostInfo(hd);
    extra.fields = info.fields;
    extra.secrets = info.secrets;
    extra.expire_at = dueOf(hd);
    return succeeded(extra);
  }
  if (st === "Pending") return pending(30, extra);
  if (st === "Fraud") return unknown("upstream_error", "上游将该订单标记为欺诈，请联系上游处理后人工核对", extra);
  return unknown("upstream_error", "上游产品状态异常：" + st, extra);
}

// 按备注（reference）分页搜索产品，最多翻 20 页
function findHostByRemark(ctx) {
  var ref = svc(ctx).reference;
  for (var page = 1; page <= MAX_SCAN_PAGES; page++) {
    var resp = api(ctx, "GET", "/host/list", { search: ref, page: page, limit: PAGE_SIZE });
    if (resp.status !== 200) throw upstreamError(classify(resp), "搜索上游产品失败：" + resp.msg);
    var d = resp.data || {};
    var list = d.list || d.host || [];
    for (var i = 0; i < list.length; i++) {
      if (str(list[i].remark).indexOf(ref) >= 0) return str(list[i].id);
    }
    var total = num(d.total || d.count);
    if (list.length < PAGE_SIZE || (total > 0 && page * PAGE_SIZE >= total)) break;
  }
  return "";
}

// ---------- 开通 ----------

// 订单已支付：写入备注、查询开通进度
function afterPaid(ctx, cp, hostId) {
  hostId = str(hostId || cp.host_id || hostIdOf(ctx));
  if (!hostId) {
    hostId = findHostByRemark(ctx);
    if (!hostId) return unknown("not_found", "上游订单已支付，但暂未找到对应产品", cp.invoice_id ? { remote_ref: str(cp.invoice_id) } : undefined);
  }
  if (cp.stage !== "paid" || str(cp.host_id) !== hostId) {
    cp.stage = "paid";
    cp.host_id = hostId;
    saveCheckpoint(ctx, cp);
  }
  if (!cp.remarked) {
    try {
      var r = api(ctx, "POST", "/host/remark", { id: hostId, remark: svc(ctx).reference });
      if (r.status === 200) {
        cp.remarked = true;
        saveCheckpoint(ctx, cp);
      } else {
        log.warn("写入上游产品备注失败：" + r.msg);
      }
    } catch (e) {
      log.warn("写入上游产品备注失败：" + errorMessage(e));
    }
  }
  var hdr = header(ctx, hostId);
  if (!hdr) return unknown("not_found", "上游产品 " + hostId + " 不存在");
  return hostResult(hostId, hdr, cp);
}

// 开通流程（可重入）：create 可新建订单；lookup / query 只续做已有订单，确认不存在时返回 not_found
function provision(ctx, mode) {
  var bad = identityError(ctx);
  if (bad) return mode === "create" ? failed("invalid_params", bad, false) : unknown("invalid_params", bad);
  var cp = checkpointOf(ctx);
  // 重入时此前可能已提交结算或支付：任何异常都只能按结果未知处理
  var risky = mode !== "create" || (!!cp.stage && cp.stage !== "cleared");
  try {
    if (cp.stage === "paid" && cp.host_id) return afterPaid(ctx, cp, cp.host_id);

    // 1. 清空购物车，同时按下游标识检查是否已有订单
    var ds = downstreamParams(ctx);
    var clear = api(ctx, "POST", "/cart/clear", ds);
    var cd = clear.data || {};
    if (clear.status !== 200) {
      if (/已开通|已支付/.test(clear.msg)) {
        risky = true;
        return afterPaid(ctx, cp, firstId(cd.hostid));
      }
      var cc = classify(clear);
      if (mode === "create" && cc !== "rate_limited") return failed(cc, "清空上游购物车失败：" + clear.msg, true);
      return unknown(cc, "清空上游购物车失败：" + clear.msg);
    }
    if (cd.invoiceid) {
      novaix.note("上游已存在该服务的未支付账单 " + cd.invoiceid + "，继续支付");
      cp.stage = "settled";
      cp.invoice_id = str(cd.invoiceid);
      if (firstId(cd.hostid)) cp.host_id = firstId(cd.hostid);
      saveCheckpoint(ctx, cp);
    } else {
      if (mode !== "create") {
        // 下游标识未能匹配时按备注兜底搜索
        var found = findHostByRemark(ctx);
        if (found) return afterPaid(ctx, cp, found);
        return failed("not_found", "上游未找到该服务的订单");
      }
      cp = { stage: "cleared" };
      saveCheckpoint(ctx, cp);

      // 2. 结算生成账单
      var data = cartData(ctx, currencyId(ctx));
      risky = true;
      var settle = api(ctx, "POST", "/cart/settle", assign({ cart_data: data }, ds));
      var sd = settle.data || {};
      if (settle.status === 1001) {
        // 0 元订单：结算即开通
        cp = { stage: "paid", host_id: firstId(sd.hostid) };
        saveCheckpoint(ctx, cp);
        return afterPaid(ctx, cp, cp.host_id);
      }
      if (settle.status !== 200) return rejected(settle, "上游结算失败");
      cp = { stage: "settled", invoice_id: str(sd.invoiceid), host_id: firstId(sd.hostid) };
      saveCheckpoint(ctx, cp);
      if (!cp.invoice_id) return unknown("upstream_error", "上游结算未返回账单号");
    }

    // 3. 余额支付
    risky = true;
    var pay = api(ctx, "POST", "/apply_credit", assign({ invoiceid: cp.invoice_id, use_credit: 1, enough: 1, is_api: 1 }, ds));
    if (!isPaid(pay)) {
      return rejected(pay, classify(pay) === "insufficient_balance" ? "上游余额不足" : "上游支付失败", { remote_ref: str(cp.invoice_id) });
    }
    if (!cp.host_id) cp.host_id = firstId(pay.data && pay.data.hostid);
    cp.stage = "paid";
    saveCheckpoint(ctx, cp);
    return afterPaid(ctx, cp, cp.host_id);
  } catch (e) {
    if (!risky) return failedBeforeSubmit(e);
    return unknownFrom(e, cp.invoice_id ? { remote_ref: str(cp.invoice_id) } : undefined);
  }
}

// ---------- 续费 ----------

function renewDone(hd, cp) {
  var extra = { expire_at: dueOf(hd) };
  if (cp.invoice_id) extra.remote_ref = str(cp.invoice_id);
  if (num(cp.price) > 0) extra.cost = num(cp.price);
  return succeeded(extra);
}

function renewCheck(ctx, hostId, cp) {
  var hdr = header(ctx, hostId);
  if (hdr && num(hdr.host_data.nextduedate) > num(cp.old_due)) return renewDone(hdr.host_data, cp);
  return pending(15, cp.invoice_id ? { remote_ref: str(cp.invoice_id) } : undefined);
}

function payRenew(ctx, hostId, cp) {
  var pay = api(ctx, "POST", "/apply_credit", { invoiceid: cp.invoice_id, use_credit: 1, enough: 1, is_api: 1 });
  if (!isPaid(pay)) {
    return rejected(pay, classify(pay) === "insufficient_balance" ? "上游余额不足" : "上游续费账单支付失败", { remote_ref: str(cp.invoice_id) });
  }
  cp.stage = "renew_paid";
  saveCheckpoint(ctx, cp);
  return renewCheck(ctx, hostId, cp);
}

// 续费不幂等：提交前在检查点记录旧到期时间，重入或查询时以到期时间是否前移判断，绝不重复提交
function renewFlow(ctx, isQuery) {
  var hostId = hostIdOf(ctx);
  if (!hostId) return isQuery ? unknown("invalid_params", "缺少上游产品 ID") : failed("invalid_params", "缺少上游产品 ID", false);
  var cp = checkpointOf(ctx);
  var risky = isQuery || cp.old_due !== undefined;
  try {
    var hdr = header(ctx, hostId);
    if (!hdr) return isQuery ? unknown("not_found", "上游产品不存在") : failed("not_found", "上游产品不存在", false);
    var hd = hdr.host_data;
    var due = num(hd.nextduedate);
    if (cp.old_due !== undefined) {
      if (due > num(cp.old_due)) return renewDone(hd, cp);
      if (cp.invoice_id) {
        risky = true;
        return payRenew(ctx, hostId, cp);
      }
      return unknown("upstream_error", "此前提交的续费结果未知且到期时间未变化，请核对上游续费账单");
    }
    if (isQuery) return failed("upstream_error", "续费请求尚未提交", true);
    if (hd.domainstatus !== "Active" && hd.domainstatus !== "Suspended") {
      return failed("upstream_error", "上游产品状态为 " + hd.domainstatus + "，无法续费", false);
    }
    var cycle = str(svc(ctx).cycle_param).trim() || str(hd.billingcycle) || DEFAULT_CYCLES[str(svc(ctx).billing_cycle)];
    if (!cycle) return failed("invalid_params", "无法确定上游续费周期", false);

    cp = { stage: "renew_submitted", old_due: due, cycle: cycle, price: toCents(hd.amount) };
    saveCheckpoint(ctx, cp);
    risky = true;
    var resp = api(ctx, "POST", "/host/renew", { hostid: hostId, billingcycles: cycle });
    if (resp.status === 1001) {
      cp.stage = "renew_paid";
      saveCheckpoint(ctx, cp);
      return renewCheck(ctx, hostId, cp);
    }
    if (resp.status !== 200) {
      // 上游明确拒绝（未生成账单）时清除检查点，允许重新提交
      if (classify(resp) !== "rate_limited") saveCheckpoint(ctx, {});
      return rejected(resp, "上游续费失败");
    }
    var invoice = str(resp.data && (resp.data.invoiceid || resp.data.invoice_id));
    if (!invoice) {
      cp.stage = "renew_paid";
      saveCheckpoint(ctx, cp);
      return renewCheck(ctx, hostId, cp);
    }
    cp.stage = "renew_invoiced";
    cp.invoice_id = invoice;
    saveCheckpoint(ctx, cp);
    return payRenew(ctx, hostId, cp);
  } catch (e) {
    if (!risky) return failedBeforeSubmit(e);
    return unknownFrom(e);
  }
}

// ---------- 模块操作 ----------

// 调用上游模块函数：独立服务器走 /dcim 接口，其余走 /provision/default
function moduleCall(ctx, hostId, func, params) {
  var type = str(svc(ctx).data && svc(ctx).data.host_type);
  if (type === "dcim" && DCIM_PATHS[func]) {
    return api(ctx, "POST", DCIM_PATHS[func], assign({ id: hostId }, params));
  }
  return api(ctx, "POST", "/provision/default", assign({ id: hostId, func: func, is_api: 1 }, params));
}

function suspend(ctx) {
  var hostId = hostIdOf(ctx);
  if (!hostId) return failed("invalid_params", "缺少上游产品 ID", false);
  var expired = str((opInfo(ctx).input || {}).reason) === "expired";
  try {
    var resp = api(ctx, "POST", "/provision/default", { id: hostId, func: "suspend", is_api: 1, reason: expired ? "到期未续费" : "下游暂停" });
    if (resp.status === 200 || /已暂停|已经暂停/.test(resp.msg)) return succeeded();
    return rejected(resp, "上游暂停失败");
  } catch (e) {
    return unknownFrom(e);
  }
}

function unsuspend(ctx) {
  var hostId = hostIdOf(ctx);
  if (!hostId) return failed("invalid_params", "缺少上游产品 ID", false);
  try {
    var resp = api(ctx, "POST", "/provision/default", { id: hostId, func: "unsuspend", is_api: 1 });
    if (resp.status === 200 || /未暂停|已激活|已恢复/.test(resp.msg)) return succeeded();
    return rejected(resp, "上游解除暂停失败");
  } catch (e) {
    return unknownFrom(e);
  }
}

function statusQuery(ctx, want, label) {
  var hostId = hostIdOf(ctx);
  if (!hostId) return unknown("invalid_params", "缺少上游产品 ID");
  try {
    var hdr = header(ctx, hostId);
    if (!hdr) return unknown("not_found", "上游产品不存在");
    var st = str(hdr.host_data.domainstatus);
    if (st === want) return succeeded({ expire_at: dueOf(hdr.host_data) });
    if (isGone(st)) return unknown("upstream_error", "上游产品已删除");
    // 暂停/解除暂停为同步接口：状态未变化说明上游没有执行
    return failed("upstream_error", "上游产品状态为 " + st + "，" + label + "未生效", true);
  } catch (e) {
    return unknownFrom(e);
  }
}

// 退订：提交立即取消申请，由上游定时任务删除，因此返回 pending
function terminate(ctx) {
  var hostId = hostIdOf(ctx);
  if (!hostId) return failed("invalid_params", "缺少上游产品 ID", false);
  var risky = false;
  try {
    var hdr = header(ctx, hostId);
    if (!hdr || isGone(str(hdr.host_data.domainstatus))) return succeeded();
    saveCheckpoint(ctx, { stage: "cancel_submitted", requested_at: nowUnix() });
    risky = true;
    var resp = api(ctx, "POST", "/host/cancel", { id: hostId, type: "Immediate", reason: "下游退订" });
    if (resp.status === 200 || /已存在取消请求|已申请|已提交/.test(resp.msg)) {
      novaix.note("已向上游提交立即取消申请，等待上游定时任务执行");
      return pending(300);
    }
    if (/已取消|已删除/.test(resp.msg)) return succeeded();
    if (classify(resp) !== "rate_limited") saveCheckpoint(ctx, {});
    return rejected(resp, "上游取消申请失败");
  } catch (e) {
    if (!risky) return failedBeforeSubmit(e);
    return unknownFrom(e);
  }
}

function terminateQuery(ctx) {
  var hostId = hostIdOf(ctx);
  if (!hostId) return unknown("invalid_params", "缺少上游产品 ID");
  var cp = checkpointOf(ctx);
  try {
    var hdr = header(ctx, hostId);
    if (!hdr || isGone(str(hdr.host_data.domainstatus))) return succeeded();
    if (!cp.stage) return failed("upstream_error", "取消申请尚未提交", true);
    return pending(600);
  } catch (e) {
    return unknownFrom(e);
  }
}

// ---------- 实例操作 ----------

// 按上游 module_button 动态生成操作，重装系统的选项来自 cloud_os
function getActions(ctx) {
  var hostId = hostIdOf(ctx);
  var hdr = null;
  if (hostId) {
    try {
      hdr = header(ctx, hostId);
    } catch (e) {
      log.warn("获取上游产品详情失败：" + errorMessage(e));
    }
  }
  var buttons = {};
  var hasButtons = false;
  var raw = hdr && hdr.module_button;
  var groups = Array.isArray(raw) ? [raw] : [];
  if (raw && !Array.isArray(raw) && typeof raw === "object") {
    for (var g in raw) {
      if (Array.isArray(raw[g])) groups.push(raw[g]);
    }
  }
  for (var i = 0; i < groups.length; i++) {
    for (var j = 0; j < groups[i].length; j++) {
      var b = groups[i][j];
      if (b && b.func) {
        buttons[str(b.func)] = str(b.name);
        hasButtons = true;
      }
    }
  }
  var actions = [];
  var order = ["on", "off", "reboot", "hard_off", "hard_reboot", "reset_password", "reinstall"];
  for (var k = 0; k < order.length; k++) {
    var name = order[k];
    var func = ACTION_FUNCS[name];
    if (hasButtons && buttons[func] === undefined) continue;
    var a = { name: name, label: ACTION_LABELS[name] };
    if (name === "off" || name === "reboot") a.confirm = "确定要" + ACTION_LABELS[name] + "吗？";
    if (name === "hard_off" || name === "hard_reboot") {
      a.confirm = ACTION_LABELS[name] + "可能导致数据丢失，确定继续吗？";
      a.danger = true;
    }
    if (name === "reset_password") {
      a.confirm = "确定要重置登录密码吗？";
      a.fields = [{ key: "password", label: "新密码", type: "password", required: true }];
    }
    if (name === "reinstall") {
      a.danger = true;
      a.confirm = "重装会清空系统盘数据，确定继续吗？";
      var osField = { key: "os", label: "操作系统", type: "text", required: true, help: "填写上游系统 ID" };
      var osList = (hdr && hdr.cloud_os) || [];
      if (osList.length) {
        var options = [];
        var seen = {};
        for (var m = 0; m < osList.length; m++) {
          var v = str(osList[m].id);
          if (!v || seen[v]) continue;
          seen[v] = true;
          options.push({ value: v, label: str(osList[m].name) || v });
        }
        if (options.length) osField = { key: "os", label: "操作系统", type: "select", required: true, options: options };
      }
      a.fields = [osField, { key: "port", label: "远程端口", type: "number", default: "22" }];
    }
    actions.push(a);
  }
  return actions;
}

function runAction(ctx, name, input) {
  var hostId = hostIdOf(ctx);
  if (!hostId) return failed("invalid_params", "缺少上游产品 ID", false);
  var func = ACTION_FUNCS[name];
  if (!func) return failed("unsupported", "不支持的操作：" + name, false);
  input = input || {};
  var params = {};
  if (name === "reset_password") {
    if (!str(input.password)) return failed("invalid_params", "请填写新密码", false);
    params.password = str(input.password);
  } else if (name === "reinstall") {
    if (!str(input.os)) return failed("invalid_params", "请选择操作系统", false);
    params.os = str(input.os);
    params.port = num(input.port) || 22;
  }
  try {
    var resp = moduleCall(ctx, hostId, func, params);
    if (resp.status !== 200) return rejected(resp, ACTION_LABELS[name] + "失败");
    var extra = {};
    if (params.password) extra.secrets = { password: params.password };
    if (name === "reinstall") {
      try {
        var hdr = header(ctx, hostId);
        if (hdr) {
          var info = hostInfo(hdr.host_data);
          extra.fields = info.fields;
          if (info.secrets) extra.secrets = info.secrets;
        }
      } catch (e2) {
        log.warn("刷新上游产品信息失败：" + errorMessage(e2));
      }
    }
    return succeeded(extra);
  } catch (e) {
    return unknownFrom(e);
  }
}

// 实例操作为同步接口，只有结果未知时才会查询：按电源状态或产品详情确认
function actionQuery(ctx) {
  var op = opInfo(ctx);
  var name = str(op.action);
  var input = op.input || {};
  var hostId = hostIdOf(ctx);
  if (!hostId) return unknown("invalid_params", "缺少上游产品 ID");
  var label = ACTION_LABELS[name] || name;
  try {
    if (name === "reset_password" || name === "reinstall") {
      var hdr = header(ctx, hostId);
      if (!hdr) return unknown("not_found", "上游产品不存在");
      var hd = hdr.host_data;
      if (name === "reset_password") {
        if (str(hd.password) && str(hd.password) === str(input.password)) return succeeded({ secrets: { password: str(input.password) } });
        return unknown("upstream_error", "未能确认" + label + "结果，请到上游核对");
      }
      var osName = "";
      var osList = hdr.cloud_os || [];
      for (var i = 0; i < osList.length; i++) {
        if (str(osList[i].id) === str(input.os)) osName = str(osList[i].name);
      }
      if (osName && str(hd.os) === osName) return succeeded({ fields: hostInfo(hd).fields });
      return unknown("upstream_error", "未能确认" + label + "结果，请到上游核对");
    }
    if (ACTION_FUNCS[name]) {
      var resp = moduleCall(ctx, hostId, "status", {});
      var power = str(resp.data && resp.data.status);
      var want = name === "off" || name === "hard_off" ? "off" : "on";
      if (power === want) return succeeded();
      if (/ing$|operating|wait|pending/.test(power)) return pending(10);
      return unknown("upstream_error", "未能确认" + label + "结果（当前电源状态：" + (power || "未知") + "）");
    }
    return unknown("unsupported", "不支持的操作：" + name);
  } catch (e) {
    return unknownFrom(e);
  }
}

function console(ctx) {
  var hostId = hostIdOf(ctx);
  if (!hostId) throw new Error("缺少上游产品 ID");
  var resp = moduleCall(ctx, hostId, "vnc", {});
  var d = resp.data || {};
  var u = str(d.url || d.link);
  if (resp.status !== 200 || !u) throw new Error("获取控制台地址失败：" + (resp.msg || "上游未返回地址"));
  if (!/^https?:\/\//i.test(u)) u = baseURL(ctx) + (u.charAt(0) === "/" ? "" : "/") + u;
  return { type: "url", url: u };
}

// ---------- 入口 ----------

function fetchBalance(ctx) {
  var resp = api(ctx, "GET", "/cart/credit");
  if (resp.status !== 200 || !resp.data) throw upstreamError(classify(resp), "查询上游余额失败：" + resp.msg);
  return toCents(resp.data.credit);
}

function testConnection(ctx) {
  try {
    novaix.cache.delete(tokenKey(ctx));
    login(ctx);
    var balance = fetchBalance(ctx);
    return { ok: true, message: "连接成功，账户余额 ¥" + yuan(balance), balance: balance };
  } catch (e) {
    return { ok: false, message: errorMessage(e) };
  }
}

function getBalance(ctx) {
  return { balance: fetchBalance(ctx) };
}

function create(ctx) {
  return provision(ctx, "create");
}

function lookup(ctx) {
  return provision(ctx, "lookup");
}

function renew(ctx) {
  return renewFlow(ctx, false);
}

function query(ctx) {
  var type = str(opInfo(ctx).type);
  switch (type) {
    case "create":
      return provision(ctx, "query");
    case "renew":
      return renewFlow(ctx, true);
    case "suspend":
      return statusQuery(ctx, "Suspended", "暂停");
    case "unsuspend":
      return statusQuery(ctx, "Active", "解除暂停");
    case "terminate":
      return terminateQuery(ctx);
    case "action":
      return actionQuery(ctx);
  }
  return unknown("invalid_params", "不支持查询的操作类型：" + type);
}

function getService(ctx) {
  var hostId = hostIdOf(ctx);
  if (!hostId) return { status: "unknown", message: "缺少上游产品 ID" };
  var hdr = header(ctx, hostId);
  if (!hdr) return { status: "terminated", message: "上游未找到该产品" };
  var hd = hdr.host_data;
  var st = str(hd.domainstatus);
  var mapping = { Active: "active", Pending: "pending", Suspended: "suspended", Fraud: "suspended", Cancelled: "terminated", Deleted: "terminated", Terminated: "terminated" };
  var out = { status: mapping[st] || "unknown", expire_at: dueOf(hd), data: { host_type: str(hd.type), upstream_status: st } };
  if (!mapping[st]) out.message = "上游产品状态：" + st;
  if (st === "Active" || st === "Suspended") {
    var info = hostInfo(hd);
    out.fields = info.fields;
    if (info.secrets) out.secrets = info.secrets;
  }
  return out;
}
