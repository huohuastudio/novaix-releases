// PushPlus 插件
// 对接文档: https://www.pushplus.plus/doc/guide/api.html

function send(title, body) {
  var payload = {
    token: config.token,
    title: title,
    content: body,
    template: config.template || "txt"
  };

  if (config.topic) {
    payload.topic = config.topic;
  }

  var resp = http.request("POST", "https://www.pushplus.plus/send", {
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
    timeout: 10
  });

  if (resp.status !== 200) {
    throw new Error("PushPlus 接口返回异常状态码 " + resp.status);
  }

  var data = JSON.parse(resp.body);
  if (data.code !== 200) {
    throw new Error("PushPlus 推送失败: " + (data.msg || "未知错误"));
  }
}
