// Cloudflare Turnstile 前端渲染
// 文档: https://developers.cloudflare.com/turnstile/get-started/client-side-rendering/

window.__novaix_captcha_init = function(container, config, callbacks) {
    function render() {
        // 组件可能在 SDK 加载期间被卸载
        if (!container.isConnected) return;
        if (!window.turnstile) {
            callbacks.onError("Turnstile SDK 加载异常");
            return;
        }
        try {
            window.__novaix_turnstile_id = window.turnstile.render(container, {
                sitekey: config.site_key,
                theme: config.theme || "auto",
                size: config.size || "flexible",
                language: "auto",
                callback: callbacks.onSuccess,
                "error-callback": function() {
                    callbacks.onError("验证失败，请重试");
                    // 返回 true 表示已处理，避免 SDK 在控制台重复抛错
                    return true;
                },
                "expired-callback": callbacks.onExpired,
                "timeout-callback": callbacks.onExpired
            });
        } catch (e) {
            callbacks.onError("验证组件初始化失败，请检查站点密钥");
        }
    }

    if (window.turnstile) {
        render();
        return;
    }

    // 表单切换时组件会重复挂载，复用已插入的 SDK 脚本
    var script = document.getElementById("novaix-turnstile-sdk");
    if (!script) {
        script = document.createElement("script");
        script.id = "novaix-turnstile-sdk";
        script.src = "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit";
        script.async = true;
        document.head.appendChild(script);
    }
    // load 与 error 只会触发其一，触发后同时移除另一个监听，避免已卸载的容器被闭包长期引用
    function onLoad() {
        script.removeEventListener("error", onFail);
        render();
    }
    function onFail() {
        script.removeEventListener("load", onLoad);
        script.remove();
        if (container.isConnected) callbacks.onError("Turnstile SDK 加载失败");
    }
    script.addEventListener("load", onLoad, { once: true });
    script.addEventListener("error", onFail, { once: true });
};

window.__novaix_captcha_destroy = function() {
    if (window.__novaix_turnstile_id != null && window.turnstile) {
        try { window.turnstile.remove(window.__novaix_turnstile_id); } catch (e) {}
    }
    delete window.__novaix_turnstile_id;
};
