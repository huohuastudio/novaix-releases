// Cloudflare Turnstile 服务端校验
// 文档: https://developers.cloudflare.com/turnstile/get-started/server-side-validation/

var VERIFY_URL = "https://challenges.cloudflare.com/turnstile/v0/siteverify";

// 常见错误码对应的用户提示，其余统一提示重新验证
var ERRORS = {
    "timeout-or-duplicate": "验证已过期，请重新验证",
    "invalid-input-response": "验证数据无效，请重新验证",
    "invalid-input-secret": "验证服务配置错误，请联系管理员",
    "missing-input-secret": "验证服务配置错误，请联系管理员"
};

function verify(req) {
    if (!req.token) {
        return { success: false, error: "请完成人机验证" };
    }
    // 官方限制 token 最长 2048 字符，超长直接拒绝，避免无意义的外部请求
    if (req.token.length > 2048) {
        return { success: false, error: ERRORS["invalid-input-response"] };
    }

    // 校验服务不可用时，按配置放行或拒绝
    function unavailable(message, error) {
        log.warn(message);
        return config.fail_open === "true" ? { success: true } : { success: false, error: error };
    }

    var params = { secret: config.secret_key, response: req.token };
    if (req.ip) params.remoteip = req.ip;

    var resp;
    try {
        resp = http.request("POST", VERIFY_URL, {
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: url.buildQuery(params),
            timeout: 5
        });
    } catch (e) {
        return unavailable("Turnstile 服务请求异常: " + e.message, "验证服务暂时不可用");
    }
    if (resp.status !== 200) {
        return unavailable("Turnstile 服务返回异常状态码 " + resp.status, "验证服务异常");
    }

    var data;
    try {
        data = JSON.parse(resp.body);
    } catch (e) {
        return unavailable("Turnstile 响应解析失败", "验证服务响应异常");
    }

    if (data.success === true) {
        return { success: true };
    }

    var codes = data["error-codes"] || [];
    for (var i = 0; i < codes.length; i++) {
        if (codes[i].indexOf("-secret") !== -1) {
            log.warn("Turnstile 密钥配置错误: " + codes[i]);
        }
        if (ERRORS[codes[i]]) return { success: false, error: ERRORS[codes[i]] };
    }
    return { success: false, error: "人机验证失败，请重试" };
}
