// 彩虹聚合登录插件
// 对接文档: https://u.cccyun.cc/doc.php

var apiBase = config.api_url.replace(/\/+$/, "");

var typeLabels = {
  "qq": "QQ",
  "wx": "微信",
  "alipay": "支付宝",
  "sina": "新浪微博",
  "baidu": "百度",
  "huawei": "华为",
  "xiaomi": "小米",
  "douyin": "抖音",
  "bilibili": "哔哩哔哩",
  "dingtalk": "钉钉",
  "google": "谷歌",
  "microsoft": "微软",
  "facebook": "Facebook",
  "twitter": "Twitter",
  "feishu": "飞书",
  "wework": "企业微信",
  "github": "GitHub"
};

function parseTypes() {
  if (!config.type) return [];
  try { return JSON.parse(config.type); } catch (e) { return []; }
}

function getMethods() {
  var types = parseTypes();
  if (types.length <= 1) return null;

  var methods = [];
  for (var i = 0; i < types.length; i++) {
    if (typeof types[i] !== "string") continue;
    var t = types[i].trim();
    if (t) {
      methods.push({ name: t, label: typeLabels[t] || t });
    }
  }
  return methods.length > 0 ? methods : null;
}

function authURL(req) {
  // 优先使用用户选择的登录方式，否则回退到管理员配置的第一个
  var loginType = req.method;
  if (!loginType) {
    var types = parseTypes();
    if (types.length > 0) loginType = types[0];
  }

  // 彩虹 API 不转发 state 参数，需编码进 redirect_uri 使其在回调中保留
  var redirectURI = req.redirectURL;
  if (req.state) {
    redirectURI += (redirectURI.indexOf("?") === -1 ? "?" : "&") + "state=" + url.encode(req.state);
  }

  var params = {
    act: "login",
    appid: config.appid,
    appkey: config.appkey,
    type: loginType,
    redirect_uri: redirectURI
  };

  var resp = http.request("GET", apiBase + "/connect.php?" + url.buildQuery(params), {
    timeout: 10
  });

  if (resp.status !== 200) {
    throw new Error("彩虹聚合登录接口返回异常状态码 " + resp.status);
  }

  var data = JSON.parse(resp.body);
  if (data.code !== 0) {
    throw new Error("彩虹聚合登录错误: " + (data.msg || "未知错误"));
  }

  if (!data.url) {
    throw new Error("彩虹聚合登录未返回授权地址");
  }

  return data.url;
}

function exchange(req) {
  // 优先使用回传的登录方式，否则回退到管理员配置的第一个
  var loginType = req.method;
  if (!loginType) {
    var types = parseTypes();
    if (types.length > 0) loginType = types[0];
  }

  var params = {
    act: "callback",
    appid: config.appid,
    appkey: config.appkey,
    type: loginType,
    code: req.code
  };

  var resp = http.request("GET", apiBase + "/connect.php?" + url.buildQuery(params), {
    timeout: 10
  });

  if (resp.status !== 200) {
    throw new Error("彩虹聚合登录获取用户信息失败: HTTP " + resp.status);
  }

  var data = JSON.parse(resp.body);
  if (data.code !== 0) {
    throw new Error("彩虹聚合登录获取用户信息失败: " + (data.msg || "未知错误"));
  }

  if (!data.social_uid) {
    throw new Error("彩虹聚合登录未返回用户标识");
  }

  return {
    providerUserID: loginType + ":" + data.social_uid,
    email: "",
    emailVerified: false,
    displayName: data.nickname || "",
    avatarURL: data.faceimg || ""
  };
}
