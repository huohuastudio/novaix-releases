// 彩虹聚合登录插件
// 对接文档: https://u.cccyun.cc/doc.php

var apiBase = config.api_url.replace(/\/+$/, "");

function authURL(req) {

  // 彩虹 API 不转发 state 参数，需编码进 redirect_uri 使其在回调中保留
  var redirectURI = req.redirectURL;
  if (req.state) {
    redirectURI += (redirectURI.indexOf("?") === -1 ? "?" : "&") + "state=" + url.encode(req.state);
  }

  var params = {
    act: "login",
    appid: config.appid,
    appkey: config.appkey,
    type: config.type,
    redirect_uri: redirectURI
  };

  var resp = http.request("GET", apiBase + "/connect.php?" + url.buildQuery(params), {
    timeout: 10
  });

  if (resp.status !== 200) {
    throw new Error("彩虹聚合登录接口返回异常状态码 " + resp.status);
  }

  var data = JSON.parse(resp.body);
  if (data.code !== 0) {
    throw new Error("彩虹聚合登录错误: " + (data.msg || "未知错误"));
  }

  if (!data.url) {
    throw new Error("彩虹聚合登录未返回授权地址");
  }

  return data.url;
}

function exchange(req) {
  var params = {
    act: "callback",
    appid: config.appid,
    appkey: config.appkey,
    type: config.type,
    code: req.code
  };

  var resp = http.request("GET", apiBase + "/connect.php?" + url.buildQuery(params), {
    timeout: 10
  });

  if (resp.status !== 200) {
    throw new Error("彩虹聚合登录获取用户信息失败: HTTP " + resp.status);
  }

  var data = JSON.parse(resp.body);
  if (data.code !== 0) {
    throw new Error("彩虹聚合登录获取用户信息失败: " + (data.msg || "未知错误"));
  }

  if (!data.social_uid) {
    throw new Error("彩虹聚合登录未返回用户标识");
  }

  return {
    providerUserID: config.type + ":" + data.social_uid,
    email: "",
    emailVerified: false,
    displayName: data.nickname || "",
    avatarURL: data.faceimg || ""
  };
}
