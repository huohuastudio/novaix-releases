// 极验行为验证 v4 服务端校验
// 文档: https://docs.geetest.com/gt4/apirefer/api/server

var VALIDATE_URL = "https://gcaptcha4.geetest.com/validate";

function verify(req) {
    var tokenData;
    try {
        tokenData = JSON.parse(req.token);
    } catch (e) {
        return { success: false, error: "验证数据格式无效" };
    }

    if (!tokenData.lot_number || !tokenData.captcha_output || !tokenData.pass_token || !tokenData.gen_time) {
        return { success: false, error: "验证数据不完整" };
    }

    var failOpen = config.fail_open !== "false";
    var signToken = crypto.hmacSHA256(config.captcha_key, tokenData.lot_number);

    var body = url.buildQuery({
        lot_number: tokenData.lot_number,
        captcha_output: tokenData.captcha_output,
        pass_token: tokenData.pass_token,
        gen_time: tokenData.gen_time,
        sign_token: signToken
    });

    var resp;
    try {
        resp = http.request("POST", VALIDATE_URL + "?captcha_id=" + url.encode(config.captcha_id), {
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: body,
            timeout: 5
        });
    } catch (e) {
        log.warn("极验服务请求异常: " + e.message);
        if (failOpen) return { success: true };
        return { success: false, error: "验证服务暂时不可用" };
    }

    if (resp.status !== 200) {
        log.warn("极验服务返回异常状态码 " + resp.status);
        if (failOpen) return { success: true };
        return { success: false, error: "验证服务异常" };
    }

    var data;
    try {
        data = JSON.parse(resp.body);
    } catch (e) {
        log.warn("极验响应解析失败");
        if (failOpen) return { success: true };
        return { success: false, error: "验证服务响应异常" };
    }

    if (data.result === "success") {
        return { success: true };
    }

    return { success: false, error: data.reason || "验证失败" };
}
