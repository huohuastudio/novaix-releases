// WHMCS 供应商插件：通过 WHMCS 经典 API（POST /includes/api.php）以一个上游客户账号下单转售。
// 插件不保存状态：多步骤下单（下单 → 余额付款 → 受理开通）的进度写入检查点，重入时从检查点续做。
// 幂等引用 ctx.service.reference 派生为上游主机名（domain/hostname），结果未知时按主机名反查。

var PAGE_SIZE = 20;
var CACHE_TTL = 300;
var LIST_PAGE = 50;     // 反查服务列表时每页条数
var LIST_MAX_PAGES = 40; // 反查最多翻页数，超过则无法确认，交给人工
var LIVE_STATUSES = {Pending: true, Active: true, Suspended: true};
var GONE_STATUSES = {Terminated: true, Cancelled: true, Fraud: true, Completed: true};
var DEFAULT_CYCLES = {monthly: "monthly", quarterly: "quarterly", yearly: "annually"};
var CYCLE_LABELS = {monthly: "月付", quarterly: "季付", semiannually: "半年付", annually: "年付", biennially: "两年付", triennially: "三年付"};

// ---------- 基础 ----------

function baseURL() {
  var u = String(config.url || "").trim().replace(/\/+$/, "").replace(/\/includes\/api\.php$/i, "");
  if (!/^https?:\/\//i.test(u)) throw new Error("WHMCS 地址无效");
  return u;
}

function clientID() {
  var id = String(config.client_id || "").trim();
  if (!/^[1-9][0-9]*$/.test(id)) throw new Error("未配置有效的上游客户 ID");
  return id;
}

// api 调用 WHMCS 接口并返回解析后的 JSON；网络错误或响应无法解析时抛异常。
// WHMCS 以 result 字段表示成败，不依赖 HTTP 状态码。
function api(action, params, timeout) {
  var body = {action: action, identifier: config.identifier || "", secret: config.secret || "", responsetype: "json"};
  if (config.accesskey) body.accesskey = config.accesskey;
  for (var k in params || {}) {
    var v = params[k];
    if (v !== undefined && v !== null && v !== "") body[k] = v;
  }
  var resp = http.request("POST", baseURL() + "/includes/api.php", {
    headers: {"Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json"},
    body: url.buildQuery(body),
    timeout: timeout || 30
  });
  var data = null;
  try { data = JSON.parse(resp.body); } catch (e) { data = null; }
  if (!data || typeof data !== "object") throw new Error("WHMCS 返回无法解析的响应（HTTP " + resp.status + "）");
  return data;
}

// tryApi 用于有副作用的调用：网络异常时返回 {error}，由调用方决定返回 pending 或 unknown
function tryApi(action, params, timeout) {
  try { return {data: api(action, params, timeout)}; }
  catch (e) { return {error: errText(e)}; }
}

function isOK(data) { return data && data.result === "success"; }
function msgOf(data) { return String((data && data.message) || "未知错误"); }
function errText(e) { return String((e && e.message) || e); }

// list 兼容 WHMCS 列表的几种形态：{key: [...]}、{key: {...}}、空字符串
function list(container, key) {
  if (!container || typeof container !== "object") return [];
  var v = container[key];
  if (Array.isArray(v)) return v;
  if (v && typeof v === "object") return [v];
  return [];
}

function cents(yuan) {
  var n = parseFloat(yuan);
  return isFinite(n) ? Math.round(n * 100) : 0;
}

function classify(msg) {
  var m = String(msg || "").toLowerCase();
  if (/authentication failed|invalid ip|invalid or missing credentials|invalid permissions|access denied|api access/.test(m)) return "auth";
  if (/credit balance|insufficient|not enough credit/.test(m)) return "insufficient_balance";
  if (/out of stock|stock level/.test(m)) return "out_of_stock";
  if (/rate limit|too many/.test(m)) return "rate_limited";
  if (/not found/.test(m)) return "not_found";
  if (/invalid|required|missing/.test(m)) return "invalid_params";
  return "upstream_error";
}

function isPermissionError(msg) { return /invalid permissions|not allowed|access denied|not supported|unsupported/i.test(String(msg || "")); }

function failed(code, message, retryable) { return {status: "failed", error: {code: code, message: message, retryable: !!retryable}}; }
function unknown(message) { return {status: "unknown", error: {code: "upstream_error", message: message}}; }
function pending(message, retryAfter, extra) {
  var r = merge({status: "pending", retry_after: retryAfter || 15}, extra || {});
  if (message) novaix.note(message);
  return r;
}
function merge(target, src) {
  for (var k in src) if (src[k] !== undefined) target[k] = src[k];
  return target;
}

function checkpointOf(ctx) {
  var cp = ctx.operation && ctx.operation.checkpoint;
  return cp && typeof cp === "object" ? merge({}, cp) : {};
}

function save(cp) { novaix.checkpoint(cp); return cp; }

function serviceID(ctx) {
  var id = String((ctx.service && ctx.service.remote_id) || "").trim();
  if (!/^[0-9]+$/.test(id)) throw new Error("服务尚未关联上游服务 ID");
  return id;
}

function hostnameFor(ctx) {
  return "nx-" + String(ctx.service.reference || "").toLowerCase().slice(0, 12) + ".novaix.local";
}

function cycleOf(ctx) {
  var c = String(ctx.service.cycle_param || "").trim();
  return c || DEFAULT_CYCLES[ctx.service.billing_cycle] || "monthly";
}

function parseKV(raw) {
  if (!raw) return null;
  var obj = raw;
  if (typeof raw === "string") {
    try { obj = JSON.parse(raw); } catch (e) { throw new Error("键值配置不是有效的 JSON"); }
  }
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return null;
  var keys = Object.keys(obj);
  return keys.length ? obj : null;
}

// ---------- PHP serialize（configoptions / customfields 需 base64(serialize(array))） ----------

// utf8Length 按 UTF-8 字节数计算字符串长度（PHP 字符串长度以字节计）
function utf8Length(s) {
  var n = 0;
  for (var i = 0; i < s.length; i++) {
    var c = s.charCodeAt(i);
    if (c < 0x80) n += 1;
    else if (c < 0x800) n += 2;
    else if (c >= 0xD800 && c <= 0xDBFF && i + 1 < s.length) {
      var d = s.charCodeAt(i + 1);
      if (d >= 0xDC00 && d <= 0xDFFF) { n += 4; i++; } else n += 3;
    } else n += 3;
  }
  return n;
}

function phpKey(k) {
  var s = String(k);
  return /^(0|-?[1-9][0-9]{0,17})$/.test(s) ? "i:" + s + ";" : phpSerialize(s);
}

function phpSerialize(v) {
  if (v === null || v === undefined) return "N;";
  if (typeof v === "boolean") return "b:" + (v ? 1 : 0) + ";";
  if (typeof v === "number") {
    if (isFinite(v) && Math.floor(v) === v && Math.abs(v) < 9007199254740992) return "i:" + v + ";";
    return "d:" + v + ";";
  }
  if (typeof v === "string") return "s:" + utf8Length(v) + ":\"" + v + "\";";
  var keys = Array.isArray(v) ? v.map(function (_, i) { return i; }) : Object.keys(v);
  var out = "a:" + keys.length + ":{";
  keys.forEach(function (k) { out += phpKey(k) + phpSerialize(v[k]); });
  return out + "}";
}

// serializeOptions 可配置选项：纯数字值按整数提交（子选项 ID 或数量）
function serializeOptions(obj, numeric) {
  var arr = {};
  Object.keys(obj).forEach(function (k) {
    var v = String(obj[k] === null || obj[k] === undefined ? "" : obj[k]).trim();
    arr[String(k).trim()] = numeric && /^[0-9]+$/.test(v) ? Number(v) : v;
  });
  return base64.encode(phpSerialize(arr));
}

// ---------- 上游查询 ----------

function paymentMethods() {
  var cached = novaix.cache.get("payment_methods");
  if (cached) return cached;
  var r = api("GetPaymentMethods", {});
  if (!isOK(r)) throw new Error("获取支付网关失败：" + msgOf(r));
  var items = list(r.paymentmethods, "paymentmethod").map(function (p) {
    return {value: String(p.module), label: String(p.displayname || p.module)};
  });
  novaix.cache.set("payment_methods", items, CACHE_TTL);
  return items;
}

function paymentMethod() {
  var pm = String(config.payment_method || "").trim();
  if (pm) return pm;
  var all = paymentMethods();
  if (!all.length) throw new Error("上游没有可用的支付网关");
  return all[0].value;
}

function productOptions() {
  var cached = novaix.cache.get("products");
  if (cached) return cached;
  var r = api("GetProducts", {}, 60);
  if (!isOK(r)) throw new Error("获取上游商品失败：" + msgOf(r));
  var items = list(r.products, "product").map(function (p) {
    var desc = [];
    var pricing = p.pricing && typeof p.pricing === "object" ? p.pricing : {};
    var currency = Object.keys(pricing)[0];
    if (currency) {
      var pr = pricing[currency] || {};
      ["monthly", "quarterly", "semiannually", "annually"].forEach(function (c) {
        if (pr[c] !== undefined && parseFloat(pr[c]) >= 0) desc.push(CYCLE_LABELS[c] + " " + (pr.prefix || "") + pr[c]);
      });
    }
    var stockOut = (p.stockcontrol === true || p.stockcontrol === "true" || p.stockcontrol === 1 || p.stockcontrol === "1") && Number(p.stocklevel) <= 0;
    if (stockOut) desc.push("缺货");
    return {value: String(p.pid), label: String(p.name || ("商品 #" + p.pid)), description: desc.join(" · ")};
  });
  novaix.cache.set("products", items, CACHE_TTL);
  return items;
}

function paginate(items, page, keyword) {
  var kw = String(keyword || "").trim().toLowerCase();
  if (kw) {
    items = items.filter(function (it) {
      return (it.value + " " + it.label + " " + (it.description || "")).toLowerCase().indexOf(kw) !== -1;
    });
  }
  var p = Math.max(1, parseInt(page, 10) || 1);
  var start = (p - 1) * PAGE_SIZE;
  return {items: items.slice(start, start + PAGE_SIZE), has_more: start + PAGE_SIZE < items.length};
}

// getProduct 按服务 ID 查询客户名下的服务，不存在返回 null；查询失败抛异常
function getProduct(sid) {
  var r = api("GetClientsProducts", {clientid: clientID(), serviceid: sid});
  if (!isOK(r)) throw new Error("查询上游服务失败：" + msgOf(r));
  var items = list(r.products, "product");
  for (var i = 0; i < items.length; i++) if (String(items[i].id) === String(sid)) return items[i];
  return null;
}

// findByDomain 按派生主机名查找服务：优先使用 domain 过滤，旧版本忽略该参数时逐页兜底匹配。
// 列表未能完整遍历时抛异常（不能据此断定"不存在"）。
function findByDomain(host) {
  var start = 0, matches = [];
  for (var page = 0; page < LIST_MAX_PAGES; page++) {
    var r = api("GetClientsProducts", {clientid: clientID(), domain: host, limitstart: start, limitnum: LIST_PAGE});
    if (!isOK(r)) throw new Error("查询上游服务列表失败：" + msgOf(r));
    var items = list(r.products, "product");
    items.forEach(function (p) {
      if (String(p.domain || "").toLowerCase() === host && LIVE_STATUSES[p.status]) matches.push(p);
    });
    var total = parseInt(r.totalresults, 10) || 0;
    start += items.length;
    if (!items.length || start >= total) {
      matches.sort(function (a, b) { return Number(b.id) - Number(a.id); });
      return matches[0] || null;
    }
  }
  if (matches.length) {
    matches.sort(function (a, b) { return Number(b.id) - Number(a.id); });
    return matches[0];
  }
  throw new Error("上游服务数量过多，未能完成反查");
}

// findRenewalInvoice 在客户未付发票中查找包含该服务（Hosting）的发票
function findRenewalInvoice(sid) {
  var r = api("GetInvoices", {userid: clientID(), status: "Unpaid", limitnum: 25});
  if (!isOK(r)) throw new Error("查询上游发票失败：" + msgOf(r));
  var invoices = list(r.invoices, "invoice").slice(0, 10);
  for (var i = 0; i < invoices.length; i++) {
    var inv = api("GetInvoice", {invoiceid: invoices[i].id});
    if (!isOK(inv)) continue;
    var items = list(inv.items, "item");
    for (var j = 0; j < items.length; j++) {
      if (String(items[j].type).toLowerCase() === "hosting" && String(items[j].relid) === String(sid)) return String(invoices[i].id);
    }
  }
  return "";
}

// payInvoice 用账户余额支付发票（幂等：先查发票状态，只有 Unpaid 才付款）。
// 返回 {paid, amount}、{insufficient: true}、{cancelled: true}（发票已取消）或 {result}（pending/unknown）
function payInvoice(invoiceId) {
  var inv;
  try { inv = api("GetInvoice", {invoiceid: invoiceId}); }
  catch (e) { return {result: pending("查询发票 #" + invoiceId + " 失败，稍后重试：" + errText(e), 15)}; }
  if (!isOK(inv)) return {result: unknown("查询发票 #" + invoiceId + " 失败：" + msgOf(inv))};
  var status = String(inv.status || "");
  var total = cents(inv.total);
  if (status === "Paid") return {paid: true, amount: total};
  if (status === "Payment Pending") return {result: pending("发票 #" + invoiceId + " 付款处理中", 30)};
  if (status === "Cancelled") return {cancelled: true};
  if (status !== "Unpaid") return {result: unknown("发票 #" + invoiceId + " 状态为 " + status + "，请到上游核对")};
  var balance = parseFloat(inv.balance);
  if (!(balance > 0)) return {paid: true, amount: total};
  var pay = tryApi("ApplyCredit", {invoiceid: invoiceId, amount: String(inv.balance), noemail: true}, 60);
  if (pay.error) return {result: pending("支付发票 #" + invoiceId + " 时连接异常，稍后复查：" + pay.error, 10)};
  if (isOK(pay.data)) {
    if (String(pay.data.invoicepaid) === "false") return {result: pending("发票 #" + invoiceId + " 尚未付清，稍后复查", 10)};
    novaix.note("已用余额支付发票 #" + invoiceId);
    return {paid: true, amount: total};
  }
  var msg = msgOf(pay.data);
  if (/not in unpaid status/i.test(msg)) return {paid: true, amount: total};
  if (/credit balance|insufficient|not enough credit/i.test(msg)) return {insufficient: true, message: msg};
  return {result: unknown("支付发票 #" + invoiceId + " 失败：" + msg)};
}

// ---------- 展示字段 ----------

function osOf(p) {
  var opts = list(p.configoptions, "configoption");
  for (var i = 0; i < opts.length; i++) {
    if (/操作系统|系统|operating ?system|^os$|image|镜像/i.test(String(opts[i].option || "")) && opts[i].value) return String(opts[i].value);
  }
  return "";
}

function serviceFields(p) {
  var fields = [];
  var ipv4 = [], ipv6 = [];
  var all = [String(p.dedicatedip || "")].concat(String(p.assignedips || "").split(/[\s,;]+/));
  all.forEach(function (ip) {
    ip = ip.trim();
    if (!ip) return;
    if (ip.indexOf(":") !== -1) { if (ipv6.indexOf(ip) === -1) ipv6.push(ip); }
    else if (ipv4.indexOf(ip) === -1) ipv4.push(ip);
  });
  if (ipv4.length) fields.push({key: "ip", label: "IP 地址", value: ipv4[0], copyable: true});
  if (ipv6.length) fields.push({key: "ipv6", label: "IPv6 地址", value: ipv6[0], copyable: true});
  if (ipv4.length > 1) fields.push({key: "extra_ips", label: "附加 IP", value: ipv4.slice(1).join(", "), copyable: true});
  if (p.username) fields.push({key: "username", label: "用户名", value: String(p.username), copyable: true});
  var os = osOf(p);
  if (os) fields.push({key: "os", label: "操作系统", value: os});
  if (p.domain) fields.push({key: "hostname", label: "主机名", value: String(p.domain), copyable: true});
  return fields;
}

function expireOf(p) {
  var d = String(p.nextduedate || "");
  return /^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(d) && d !== "0000-00-00" ? d : undefined;
}

function secretsOf(p) { return p.password ? {password: String(p.password)} : undefined; }

// ---------- 开通 ----------

function placeOrder(ctx) {
  if (!/^[0-9a-f]{32}$/.test(String(ctx.service.reference || ""))) return {result: failed("invalid_params", "服务缺少有效的幂等引用")};
  var pid = String((ctx.product || {}).pid || "").trim();
  if (!/^[0-9]+$/.test(pid)) return {result: failed("invalid_params", "商品未配置上游商品")};
  var host = hostnameFor(ctx);
  var params = {
    clientid: clientID(), paymentmethod: paymentMethod(),
    "pid[0]": pid, "billingcycle[0]": cycleOf(ctx), "domain[0]": host, "hostname[0]": host,
    noemail: true, noinvoiceemail: true
  };
  var pw = ctx.service.checkout && ctx.service.checkout.password;
  if (pw) params["rootpw[0]"] = String(pw);
  var co, cf;
  try { co = parseKV(ctx.product.configoptions); cf = parseKV(ctx.product.customfields); }
  catch (e) { return {result: failed("invalid_params", errText(e))}; }
  if (co) params["configoptions[0]"] = serializeOptions(co, true);
  if (cf) params["customfields[0]"] = serializeOptions(cf, false);

  // 提交前写入检查点；此后结果未知时由主程序调用 lookup 按主机名反查
  save({stage: "ordering", hostname: host});
  var r = tryApi("AddOrder", params, 60);
  if (r.error) return {result: unknown("提交上游订单时连接异常：" + r.error)};
  if (!isOK(r.data)) {
    save({});
    var msg = msgOf(r.data);
    return {result: failed(classify(msg), "上游下单失败：" + msg, false)};
  }
  var orderId = String(r.data.orderid || "");
  var sid = String(r.data.serviceids || "").split(",")[0].trim();
  if (!sid) return {result: unknown("上游已创建订单 #" + orderId + "，但未返回服务 ID")};
  var invoiceId = String(r.data.invoiceid || "");
  if (invoiceId === "0") invoiceId = "";
  novaix.note("上游订单 #" + orderId + " 已创建，服务 #" + sid + (invoiceId ? "，发票 #" + invoiceId : ""));
  return {cp: save({stage: "ordered", hostname: host, order_id: orderId, service_id: sid, invoice_id: invoiceId})};
}

// REORDER advanceCreate 的特殊返回值：检查点中的上游订单已确认取消，需要重新下单
var REORDER = {reorder: true};

// orderCancelled 上游订单已确认取消：清空检查点中的订单信息（保留主机名），之后重试会重新下单。
// 已取消的服务不在反查范围内（findByDomain 只匹配有效状态），因此不会被误认为已创建
function orderCancelled(cp) {
  novaix.note("上游订单 #" + cp.order_id + " 已取消，重试时将重新下单");
  save({stage: "cancelled", hostname: cp.hostname, cancelled_order_id: cp.order_id});
  return REORDER;
}

// advanceCreate 从检查点续做：付款 → 受理开通 → 等待 Active
function advanceCreate(ctx, cp) {
  var progress = {remote_id: cp.service_id, remote_ref: cp.order_id, data: {order_id: cp.order_id, invoice_id: cp.invoice_id || null, hostname: cp.hostname}};
  if (cp.invoice_id && !cp.paid) {
    var pay = payInvoice(cp.invoice_id);
    if (pay.cancelled) return orderCancelled(cp);
    if (pay.insufficient) {
      // 上游未扣款也未开通：取消未付订单后返回失败。
      // 确认取消时清空订单信息，充值后重试会重新下单；未能确认时保留订单信息，重试时按发票状态续做（未付则付款，已取消则重新下单）
      var c = tryApi("CancelOrder", {orderid: cp.order_id, cancelsub: true, noemail: true});
      var cancelled = !c.error && (isOK(c.data) || /already cancelled/i.test(msgOf(c.data)));
      if (cancelled) orderCancelled(cp);
      else save(merge(cp, {stage: "cancel_unconfirmed"}));
      return merge(failed("insufficient_balance", "上游账户余额不足（" + pay.message + "），" + (cancelled ? "已取消" : "未能确认取消") + "上游未支付订单 #" + cp.order_id + "，充值后可重试", false), {remote_ref: cp.order_id});
    }
    if (pay.result) return merge(pay.result, progress);
    if (!pay.paid) return merge(unknown("发票 #" + cp.invoice_id + " 支付结果无法确认"), progress);
    cp.paid = true;
    cp.amount = pay.amount;
    save(cp);
  }

  var p;
  try { p = getProduct(cp.service_id); }
  catch (e) { return pending("查询上游服务失败，稍后重试：" + errText(e), 15, progress); }
  if (!p) return merge(unknown("上游未找到服务 #" + cp.service_id), progress);

  if (p.status === "Pending" && !cp.accepted && (cp.accept_tries || 0) < 3) {
    cp.accept_tries = (cp.accept_tries || 0) + 1;
    save(cp);
    var a = tryApi("AcceptOrder", {orderid: cp.order_id, autosetup: true, sendemail: false}, 60);
    if (a.error) return pending("受理上游订单时连接异常，稍后复查：" + a.error, 15, progress);
    if (isOK(a.data) || /not pending|already/i.test(msgOf(a.data))) {
      cp.accepted = true;
      save(cp);
      try { p = getProduct(cp.service_id) || p; } catch (e) { return pending("查询上游服务失败，稍后重试", 15, progress); }
    } else {
      return pending("上游受理开通失败：" + msgOf(a.data), 60, progress);
    }
  }

  if (p.status === "Active" || p.status === "Suspended") {
    return merge({
      status: "succeeded", fields: serviceFields(p), secrets: secretsOf(p), expire_at: expireOf(p),
      cost: cp.amount !== undefined ? cp.amount : undefined
    }, progress);
  }
  if (p.status === "Pending") return pending("上游服务开通中", 15, progress);
  if (cp.paid) return merge(unknown("上游服务状态为 " + p.status + "，已付款，请到上游核对"), progress);
  return merge(failed("upstream_error", "上游服务状态为 " + p.status + "，订单未生效", false), progress);
}

function create(ctx) {
  var cp = checkpointOf(ctx);
  if (cp.service_id) {
    var res = advanceCreate(ctx, cp);
    if (res !== REORDER) return res;
  }
  var placed = placeOrder(ctx);
  if (placed.result) return placed.result;
  var out = advanceCreate(ctx, placed.cp);
  return out === REORDER ? failed("upstream_error", "上游订单 #" + placed.cp.order_id + " 刚创建即被取消，请到上游核对", false) : out;
}

function lookup(ctx) {
  var cp = checkpointOf(ctx);
  if (cp.service_id) {
    var res = advanceCreate(ctx, cp);
    // 订单已确认取消：返回未找到，由主程序沿用同一幂等键重新提交
    if (res === REORDER) return failed("not_found", "上游订单 #" + cp.order_id + " 已取消");
    return res;
  }
  var host = hostnameFor(ctx);
  var found = findByDomain(host);
  if (!found) return failed("not_found", "上游未找到主机名为 " + host + " 的服务");
  cp = resolveOrder(found, host);
  novaix.note("按主机名反查到上游服务 #" + cp.service_id + "（订单 #" + cp.order_id + "）");
  var out = advanceCreate(ctx, cp);
  return out === REORDER ? failed("not_found", "上游订单 #" + cp.order_id + " 已取消") : out;
}

// resolveOrder 由上游服务补全订单与发票信息并写入检查点，供续做付款与受理
function resolveOrder(p, host) {
  var cp = {stage: "ordered", hostname: host, order_id: String(p.orderid || ""), service_id: String(p.id), invoice_id: ""};
  if (cp.order_id && cp.order_id !== "0") {
    var o = api("GetOrders", {id: cp.order_id});
    if (!isOK(o)) throw new Error("查询上游订单失败：" + msgOf(o));
    var order = list(o.orders, "order")[0];
    if (order && order.invoiceid && String(order.invoiceid) !== "0") cp.invoice_id = String(order.invoiceid);
  }
  return save(cp);
}

// ---------- 续费 ----------

function renew(ctx) {
  var sid = serviceID(ctx);
  var cp = checkpointOf(ctx);
  if (cp.old_due === undefined) {
    var p0 = getProduct(sid);
    if (!p0) return failed("not_found", "上游未找到服务 #" + sid);
    cp.old_due = String(p0.nextduedate || "");
    save(cp);
  }
  // 最多两轮：续费发票在上游被取消（如余额不足后上游取消了未付续费单）时，重新提交一次续费订单
  for (var round = 0; !cp.paid; round++) {
    if (!cp.invoice_id) {
      var placed = placeRenewal(sid, cp);
      if (placed) return placed;
    }
    var pay = payInvoice(cp.invoice_id);
    if (pay.cancelled) {
      var pc = getProduct(sid);
      if (pc && dueAdvanced(pc, cp)) return renewDone(sid, cp, pc);
      if (round > 0) return merge(failed("upstream_error", "上游续费发票 #" + cp.invoice_id + " 刚创建即被取消，请到上游核对", false), {remote_ref: cp.invoice_id});
      novaix.note("续费发票 #" + cp.invoice_id + " 已在上游取消，重新提交续费订单");
      cp = save({old_due: cp.old_due, cancelled_invoice_id: cp.invoice_id});
      continue;
    }
    if (pay.insufficient) return merge(failed("insufficient_balance", "上游账户余额不足（" + pay.message + "），续费发票 #" + cp.invoice_id + " 未支付", false), {remote_ref: cp.invoice_id});
    if (pay.result) return pay.result;
    // 只有确认付款成功才记录已支付，避免之后跳过付款一直等待到期时间更新
    if (!pay.paid) return unknown("续费发票 #" + cp.invoice_id + " 支付结果无法确认");
    cp.paid = true;
    cp.amount = pay.amount;
    save(cp);
  }
  var p = getProduct(sid);
  if (p && dueAdvanced(p, cp)) return renewDone(sid, cp, p);
  return pending("续费已支付，等待上游更新到期时间", 15, {remote_ref: cp.invoice_id});
}

// placeRenewal 提交续费订单（或找回上次提交的续费发票），成功时把发票号写入 cp 并返回 null，否则返回结果
function placeRenewal(sid, cp) {
  if (cp.stage === "renew_ordering") {
    // 上次提交结果未知：到期已前移即成功，否则查找对应的未付发票
    var p1 = getProduct(sid);
    if (p1 && dueAdvanced(p1, cp)) return renewDone(sid, cp, p1);
    var found = findRenewalInvoice(sid);
    if (!found) return unknown("续费订单提交结果未知，上游未找到对应的未付发票");
    cp.invoice_id = found;
    save(cp);
    return null;
  }
  var params = {clientid: clientID(), paymentmethod: paymentMethod(), "servicerenewals[0]": sid, noemail: true, noinvoiceemail: true};
  cp.stage = "renew_ordering";
  save(cp);
  var r = tryApi("AddOrder", params, 60);
  if (r.error) return unknown("提交上游续费订单时连接异常：" + r.error);
  if (isOK(r.data) && r.data.invoiceid && String(r.data.invoiceid) !== "0") {
    cp.invoice_id = String(r.data.invoiceid);
    cp.order_id = String(r.data.orderid || "");
    novaix.note("上游续费订单 #" + cp.order_id + " 已创建，发票 #" + cp.invoice_id);
  } else {
    // 旧版本不支持续费订单，或已有续费发票：回退为支付现有未付发票
    var reason = isOK(r.data) ? "未返回发票" : msgOf(r.data);
    var inv = findRenewalInvoice(sid);
    if (!inv) {
      save({old_due: cp.old_due});
      return failed(classify(reason) === "insufficient_balance" ? "insufficient_balance" : "upstream_error", "上游续费下单失败：" + reason, false);
    }
    novaix.note("续费下单未成功（" + reason + "），改为支付已有续费发票 #" + inv);
    cp.invoice_id = inv;
  }
  save(cp);
  return null;
}

// dueAdvanced 下次到期日是否已前移；续费前到期日无效时以已付款为准
function dueAdvanced(p, cp) {
  if (!expireOf(p)) return false;
  if (!/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(cp.old_due || "") || cp.old_due === "0000-00-00") return !!cp.paid;
  return String(p.nextduedate) > cp.old_due;
}

function renewDone(sid, cp, p) {
  return {status: "succeeded", remote_ref: cp.invoice_id, expire_at: expireOf(p), cost: cp.amount, fields: serviceFields(p), secrets: secretsOf(p)};
}

// ---------- 暂停 / 恢复 / 退订 ----------

function moduleToggle(ctx, action, target) {
  var sid = serviceID(ctx);
  var p = getProduct(sid);
  if (!p) return failed("not_found", "上游未找到服务 #" + sid);
  if (p.status === target) return {status: "succeeded"};
  var params = {serviceid: sid};
  if (action === "ModuleSuspend") params.suspendreason = "分销商暂停";
  var r = tryApi(action, params, 60);
  if (r.error) return unknown("调用上游 " + action + " 时连接异常：" + r.error);
  if (isOK(r.data)) return {status: "succeeded"};
  var msg = msgOf(r.data);
  if (isPermissionError(msg)) return failed("unsupported", "上游不允许 " + action + "：" + msg, false);
  var again = getProduct(sid);
  if (again && again.status === target) return {status: "succeeded"};
  return failed(classify(msg), "上游 " + action + " 失败：" + msg, false);
}

function suspend(ctx) { return moduleToggle(ctx, "ModuleSuspend", "Suspended"); }
function unsuspend(ctx) { return moduleToggle(ctx, "ModuleUnsuspend", "Active"); }

function terminate(ctx) {
  var sid = serviceID(ctx);
  var p = getProduct(sid);
  if (!p) return unknown("上游未找到服务 #" + sid + "，请人工核对是否已删除");
  if (GONE_STATUSES[p.status]) return {status: "succeeded"};
  var mode = String(config.terminate_mode || "cancel_request");
  if (mode === "module_terminate") {
    var t = tryApi("ModuleTerminate", {serviceid: sid}, 60);
    if (t.error) return unknown("调用上游终止接口时连接异常：" + t.error);
    var after = getProduct(sid);
    if (after && GONE_STATUSES[after.status]) return {status: "succeeded"};
    if (isOK(t.data)) return pending("已请求上游终止服务，等待状态更新", 15);
    var msg = msgOf(t.data);
    return failed(isPermissionError(msg) ? "unsupported" : classify(msg), "上游终止服务失败：" + msg, false);
  }
  var c = tryApi("AddCancelRequest", {serviceid: sid, type: "Immediate", reason: "分销商退订"}, 60);
  if (c.error) return unknown("提交上游取消申请时连接异常：" + c.error);
  if (isOK(c.data) || /existing|already/i.test(msgOf(c.data))) return pending("已向上游提交取消申请，等待上游处理", 600);
  return failed(classify(msgOf(c.data)), "提交上游取消申请失败：" + msgOf(c.data), false);
}

// ---------- 查询 ----------

function query(ctx) {
  var op = ctx.operation || {};
  switch (op.type) {
    case "create": {
      var cp = checkpointOf(ctx);
      if (!cp.service_id && ctx.service.remote_id) {
        var p = getProduct(String(ctx.service.remote_id));
        if (!p) return failed("not_found", "上游未找到服务 #" + ctx.service.remote_id);
        cp = resolveOrder(p, hostnameFor(ctx));
      }
      if (!cp.service_id) return lookup(ctx);
      return advanceCreate(ctx, cp);
    }
    case "renew":
      return renew(ctx);
    case "suspend":
      return suspend(ctx);
    case "unsuspend":
      return unsuspend(ctx);
    case "terminate":
      return terminate(ctx);
    case "action":
      return queryAction(ctx, op.action, op.input || {});
  }
  return unknown("不支持查询的操作类型：" + op.type);
}

function queryAction(ctx, name, input) {
  if (name === "change_password") {
    var p = getProduct(serviceID(ctx));
    if (p && input.password && String(p.password) === String(input.password)) return {status: "succeeded", secrets: {password: String(input.password)}};
    return runAction(ctx, name, input);
  }
  return unknown("无法确认上游自定义操作的执行结果，请到上游核对");
}

// ---------- 服务信息 / 余额 / 连接 ----------

function getService(ctx) {
  var sid = serviceID(ctx);
  var p = getProduct(sid);
  if (!p) return {status: "unknown", message: "上游未找到服务 #" + sid};
  var map = {Active: "active", Pending: "pending", Suspended: "suspended", Terminated: "terminated", Cancelled: "terminated", Fraud: "terminated", Completed: "terminated"};
  return {
    status: map[p.status] || "unknown", expire_at: expireOf(p), fields: serviceFields(p), secrets: secretsOf(p),
    message: p.status === "Suspended" && p.suspensionreason ? "上游暂停原因：" + p.suspensionreason : ""
  };
}

function clientDetails() {
  var r = api("GetClientsDetails", {clientid: clientID(), stats: false});
  if (!isOK(r)) throw new Error("查询上游客户失败：" + msgOf(r));
  var c = r.client && typeof r.client === "object" ? r.client : r;
  var credit = c.credit !== undefined ? c.credit : r.credit;
  return {name: String(c.fullname || ((c.firstname || "") + (c.lastname || "")) || c.email || ""), balance: cents(credit)};
}

function testConnection(ctx) {
  try {
    var d = clientDetails();
    paymentMethod();
    return {ok: true, message: "连接成功，上游客户：" + (d.name || clientID()), balance: d.balance};
  } catch (e) {
    return {ok: false, message: errText(e)};
  }
}

function getBalance(ctx) { return {balance: clientDetails().balance}; }

function getOptions(ctx, fieldKey, values, opts) {
  opts = opts || {};
  var items;
  if (fieldKey === "pid") items = productOptions();
  else if (fieldKey === "payment_method") items = paymentMethods();
  else return {items: [], has_more: false};
  return paginate(items, opts.page, opts.keyword);
}

// ---------- 自定义操作 / 控制台 ----------

function customButtons() {
  try { return parseKV(config.custom_buttons) || {}; } catch (e) { return {}; }
}

function getActions(ctx) {
  var actions = [{
    name: "change_password", label: "重置密码", confirm: "确定要重置登录密码吗？",
    fields: [{key: "password", label: "新密码", type: "password", required: true, validation: {min_length: 8, message: "密码至少 8 位"}}]
  }];
  var buttons = customButtons();
  Object.keys(buttons).forEach(function (fn) {
    if (!/^[A-Za-z0-9_]{1,64}$/.test(fn)) return;
    actions.push({name: "custom_" + fn, label: String(buttons[fn] || fn), confirm: "确定要执行「" + String(buttons[fn] || fn) + "」吗？"});
  });
  return actions;
}

function runAction(ctx, name, input) {
  input = input || {};
  var sid = serviceID(ctx);
  var r, pw;
  if (name === "change_password") {
    pw = String(input.password || "");
    if (pw.length < 8) return failed("invalid_params", "密码至少 8 位");
    r = tryApi("ModuleChangePw", {serviceid: sid, servicepassword: pw}, 60);
  } else if (name.indexOf("custom_") === 0) {
    var fn = name.slice(7);
    if (!Object.prototype.hasOwnProperty.call(customButtons(), fn)) return failed("invalid_params", "未配置的自定义操作：" + fn);
    r = tryApi("ModuleCustom", {serviceid: sid, func_name: fn}, 60);
  } else {
    return failed("invalid_params", "不支持的操作：" + name);
  }
  if (r.error) return unknown("调用上游操作时连接异常：" + r.error);
  if (!isOK(r.data)) {
    var msg = msgOf(r.data);
    return failed(isPermissionError(msg) ? "unsupported" : classify(msg), "上游操作失败：" + msg, false);
  }
  var out = {status: "succeeded"};
  if (pw) out.secrets = {password: pw};
  return out;
}

function console(ctx) {
  if (String(config.sso_console) !== "true") throw new Error("未启用控制台单点登录");
  var r = api("CreateSsoToken", {client_id: clientID(), destination: "clientarea:product_details", service_id: serviceID(ctx)});
  if (!isOK(r) || !r.redirect_url) throw new Error("生成单点登录链接失败：" + msgOf(r));
  return {type: "url", url: String(r.redirect_url), expires_in: 60};
}
