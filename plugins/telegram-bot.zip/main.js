// Telegram 仅使用通用扩展 API，消息协议和指令处理均留在插件中。
function telegram(method, body) {
  var response = http.request("POST", "https://api.telegram.org/bot" + config.bot_token + "/" + method, {
    headers: {"Content-Type": "application/json"}, body: JSON.stringify(body), timeout: 10
  });
  var result = JSON.parse(response.body);
  if (response.status !== 200 || !result.ok) throw new Error("机器人请求失败");
  return result.result;
}
function secret() { return crypto.hmacSHA256(config.bot_token, "novaix-extension-webhook"); }
function reply(chat, text, keyboard) {
  var body = {chat_id: chat, text: text};
  if (keyboard) body.reply_markup = {inline_keyboard: keyboard};
  telegram("sendMessage", body);
}
function onSchedule() {
  var callback = config._webhook_url;
  if (callback.indexOf("https://") !== 0) throw new Error("请配置 HTTPS 站点地址");
  var fingerprint = crypto.sha256(config.bot_token + "|" + callback);
  if (novaix.storage.get("webhook") === fingerprint) return;
  telegram("setWebhook", {url: callback, secret_token: secret(), allowed_updates: ["message", "callback_query"], max_connections: 1});
  novaix.storage.set("webhook", fingerprint);
}
function response(status) { return {status: status, content_type: "application/json", body: JSON.stringify({ok: status === 200})}; }
function onWebhook(request) {
  if (request.method !== "POST") return response(405);
  if (!crypto.constantTimeEqual(request.headers["x-telegram-bot-api-secret-token"] || "", secret())) return response(403);
  var update;
  try { update = JSON.parse(request.body); } catch (_) { return response(400); }
  if (!update || !Number.isSafeInteger(update.update_id)) return response(400);
  // Telegram 会重试回调；保留最近的处理记录，避免重复回复或执行操作。
  var processed = novaix.storage.get("processed") || [];
  if (processed.indexOf(update.update_id) !== -1) return response(200);
  var callback = update.callback_query;
  var message = callback ? callback.message : update.message;
  var from = callback ? callback.from : message && message.from;
  if (!message || !message.chat || !from || !Number.isSafeInteger(from.id) || from.id <= 0 || from.is_bot || message.chat.type !== "private" || message.chat.id !== from.id) return response(200);
  var external = String(from.id);
  try {
    if (callback) handleCallback(external, callback);
    else handleMessage(external, typeof message.text === "string" ? message.text : "");
  } catch (_) {
    reply(external, "操作未完成，请检查账号绑定、实例状态或稍后重试。");
  }
  processed.push(update.update_id);
  novaix.storage.set("processed", processed.slice(-100));
  return response(200);
}
function handleMessage(external, text) {
  var parts = text.trim().split(/\s+/);
  var command = parts[0].split("@")[0];
  if (command === "/start" || command === "/help") {
    reply(external, "请先在个人资料的扩展连接中生成配对码，再发送 /connect 配对码。\n/servers [页码] 查看服务器\n/status 实例ID 查看详情\n/startvm 实例ID 启动\n/stop 实例ID 停止\n/restart 实例ID 重启\n/unbind 解除绑定");
  } else if (command === "/connect") {
    novaix.storage.delete("confirm:" + external);
    novaix.accounts.bind(external, parts[1] || "");
    reply(external, "账号绑定成功，可发送 /servers 查看服务器。");
  } else if (command === "/unbind") {
    novaix.storage.delete("confirm:" + external);
    novaix.accounts.unbind(external);
    reply(external, "已解除账号绑定。");
  } else if (command === "/servers" || command === "/server") {
    var page = Number(parts[1] || 1);
    var result = novaix.instances.list(external, page);
    var lines = result.items.map(function (item) { return item.id + " · " + item.name + " · " + item.status; });
    reply(external, lines.length ? lines.join("\n") + "\n第 " + result.page + " 页，共 " + result.total + " 台" : "暂无服务器。");
  } else if (command === "/status") {
    var item = novaix.instances.get(external, Number(parts[1]));
    reply(external, item.id + " · " + item.name + "\n状态：" + item.status + "\nCPU：" + item.cpu + "\n内存：" + item.memory + " MB\n地址：" + (item.ip_address || item.ipv6_address || "暂无") + "\n到期：" + (item.expire_at || "未设置"));
  } else if (["/startvm", "/stop", "/restart"].indexOf(command) !== -1) {
    var id = Number(parts[1]);
    var instance = novaix.instances.get(external, id);
    var action = command === "/startvm" ? "start" : command.slice(1);
    var token = crypto.randomHex(16);
    novaix.storage.set("confirm:" + external, {token: token, id: id, action: action, expires: Date.now() + 60000});
    var label = {start: "启动", stop: "停止", restart: "重启"}[action];
    reply(external, "确认" + label + "服务器「" + instance.name + "」？确认按钮一分钟内有效。", [[{text: "确认" + label, callback_data: token}]]);
  } else {
    reply(external, "未知指令，请发送 /help 查看帮助。");
  }
}
function handleCallback(external, callback) {
  var pending = novaix.storage.get("confirm:" + external);
  if (!pending || pending.token !== callback.data || pending.expires < Date.now()) {
    telegram("answerCallbackQuery", {callback_query_id: callback.id, text: "操作已失效，请重新发送指令。"});
    return;
  }
  // 先消费确认信息，即使回复失败重试也不会重复提交电源操作。
  novaix.storage.delete("confirm:" + external);
  var job = novaix.instances.action(external, pending.id, pending.action);
  telegram("answerCallbackQuery", {callback_query_id: callback.id, text: "操作已提交"});
  reply(external, "操作已提交，任务编号：" + job.task_id);
}
function onEvent(event) {
  reply(event.external_id, "服务器 " + event.instance_id + " 的任务 " + event.task_id + (event.status === "completed" ? " 已完成。" : " 执行失败，请在控制台查看详情。"));
}
