// Telegram 仅使用通用扩展 API，消息协议和指令处理均留在插件中。
var COMMANDS = [{command: "start", description: "打开主菜单"}, {command: "servers", description: "查看我的服务器"}, {command: "help", description: "查看使用帮助"}, {command: "unbind", description: "解除账号绑定"}];
var STATES = {running: ["🟢", "运行中"], stopped: ["⚪", "已停止"], frozen: ["🔒", "已冻结"], error: ["🔴", "异常"], creating: ["🟡", "创建中"], rescue: ["🛟", "救援模式"]};
var ACTIONS = {start: "启动", stop: "停止", restart: "重启"};
var MENU_ROW = [{text: "🏠 返回主菜单", callback_data: "menu"}];
function telegram(method, body) {
  var response = http.request("POST", "https://api.telegram.org/bot" + config.bot_token + "/" + method, {
    headers: {"Content-Type": "application/json"}, body: JSON.stringify(body), timeout: 10
  });
  var result = JSON.parse(response.body);
  if (response.status !== 200 || !result.ok) throw new Error(result.description || "机器人请求失败");
  return result.result;
}
function secret() { return crypto.hmacSHA256(config.bot_token, "novaix-extension-webhook"); }
function html(value) { return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
function icon(status) { return (STATES[status] || ["🔵"])[0]; }
function state(status) { return STATES[status] ? STATES[status].join(" ") : "🔵 " + html(status || "未知"); }
// 正整数参数，不合法时返回 0。
function positive(value) { return /^[1-9][0-9]{0,14}$/.test(value || "") ? Number(value) : 0; }
// 优先使用宿主提供的展示名，兼容未提供该字段的旧版本。
function title(item) { return item.display_name || item.hostname || item.name; }
// 按码点截断，避免把 emoji 等代理对拆成孤立代理导致 Telegram 拒绝请求。
function shorten(value, size) { var chars = Array.from(String(value)); return chars.length > size ? chars.slice(0, size - 1).join("") + "…" : chars.join(""); }
function date(value) { return value ? String(value).slice(0, 16).replace("T", " ") : "未设置"; }
function reply(chat, text, keyboard, messageId) {
  var body = {chat_id: chat, text: text, parse_mode: "HTML"};
  if (messageId) {
    body.message_id = messageId;
    body.reply_markup = {inline_keyboard: keyboard || []};
    try { telegram("editMessageText", body); }
    catch (error) { if (String(error.message).indexOf("message is not modified") === -1) throw error; }
  } else {
    if (keyboard) body.reply_markup = {inline_keyboard: keyboard};
    telegram("sendMessage", body);
  }
}
function onSchedule() {
  var callback = config._webhook_url;
  if (callback.indexOf("https://") !== 0) throw new Error("请配置 HTTPS 站点地址");
  // 指令列表变化时指纹随之变化，升级后会自动重新注册。
  var fingerprint = crypto.sha256(config.bot_token + "|" + callback + "|" + JSON.stringify(COMMANDS));
  if (novaix.storage.get("webhook") === fingerprint) return;
  telegram("setWebhook", {url: callback, secret_token: secret(), allowed_updates: ["message", "callback_query"], max_connections: 1});
  telegram("setMyCommands", {commands: COMMANDS});
  novaix.storage.set("webhook", fingerprint);
}
function response(status, body) { return {status: status, content_type: "application/json", body: JSON.stringify(body || {ok: status === 200})}; }
function onWebhook(request) {
  if (request.method !== "POST") return response(405);
  if (!crypto.constantTimeEqual(request.headers["x-telegram-bot-api-secret-token"] || "", secret())) return response(403);
  var update;
  try { update = JSON.parse(request.body); } catch (_) { return response(400); }
  if (!update || !Number.isSafeInteger(update.update_id)) return response(400);
  // Telegram 会重试回调；保留最近的处理记录，避免重复回复或执行操作。
  var processed = novaix.storage.get("processed") || [];
  if (processed.indexOf(update.update_id) !== -1) return response(200);
  var callback = update.callback_query;
  var message = callback ? callback.message : update.message;
  var from = callback ? callback.from : message && message.from;
  if (!message || !message.chat || !from || !Number.isSafeInteger(from.id) || from.id <= 0 || from.is_bot || message.chat.type !== "private" || message.chat.id !== from.id) return response(200);
  var external = String(from.id);
  var notice;
  try {
    if (callback) notice = handleCallback(external, callback);
    else handleMessage(external, typeof message.text === "string" ? message.text : "");
  } catch (_) {
    reply(external, "⚠️ <b>操作未完成</b>\n请检查账号绑定或实例状态，稍后重试。", [MENU_ROW]);
  }
  processed.push(update.update_id);
  novaix.storage.set("processed", processed.slice(-100));
  if (!callback) return response(200);
  // 通过回调响应直接应答按钮点击，省去一次对 Telegram 的请求。
  var answer = {method: "answerCallbackQuery", callback_query_id: callback.id};
  if (notice) answer.text = notice;
  return response(200, answer);
}
function showMenu(external, messageId) {
  reply(external, "👋 <b>云服务器助手</b>\n\n使用下方按钮管理您的服务器。首次使用请先在客户中心生成配对码，并发送 <code>/connect 配对码</code>。", [[{text: "🖥 我的服务器", callback_data: "page:1"}], [{text: "📖 使用帮助", callback_data: "help"}, {text: "🔓 解除绑定", callback_data: "unbind"}]], messageId);
}
function showHelp(external, messageId) {
  reply(external, "📖 <b>使用帮助</b>\n\n🔗 <b>绑定账号</b>\n在个人资料 → 扩展连接生成配对码，复制 <code>/connect 配对码</code> 并发送到这里。\n\n🖥 点击“我的服务器”选择实例，查看状态、备注、地址和到期时间。\n⚡ 在实例详情中点选电源操作，再确认执行。\n🔒 解除绑定前也会再次确认。\n\n也可使用 <code>/servers</code>、<code>/status 实例ID</code>、<code>/startvm 实例ID</code>、<code>/stop 实例ID</code>、<code>/restart 实例ID</code>。", [MENU_ROW], messageId);
}
function showServers(external, page, messageId) {
  var result = novaix.instances.list(external, page);
  var rows = result.items.map(function (item) {
    return [{text: icon(item.status) + " " + shorten(title(item) + (item.remark ? "（" + item.remark + "）" : ""), 40) + " · #" + item.id, callback_data: "view:" + item.id + ":" + page}];
  });
  var pages = [];
  if (page > 1) pages.push({text: "⬅️ 上一页", callback_data: "page:" + (page - 1)});
  if (page * (result.page_size || 20) < result.total) pages.push({text: "下一页 ➡️", callback_data: "page:" + (page + 1)});
  if (pages.length) rows.push(pages);
  rows.push(MENU_ROW);
  reply(external, result.items.length ? "📋 <b>我的云服务器</b>\n共 " + result.total + " 台 · 第 " + page + " 页\n点击下方服务器查看详情。" : "📭 <b>暂无服务器</b>\n您可以在客户中心选购云服务器。", rows, messageId);
}
function showInstance(external, id, page, messageId) {
  var item = novaix.instances.get(external, id);
  var rows = [];
  if (item.status === "running") rows.push([{text: "🔄 重启", callback_data: "action:restart:" + id + ":" + page}, {text: "⏹️ 停止", callback_data: "action:stop:" + id + ":" + page}]);
  if (item.status === "stopped") rows.push([{text: "▶️ 启动", callback_data: "action:start:" + id + ":" + page}]);
  rows.push([{text: "🔃 刷新", callback_data: "view:" + id + ":" + page}, {text: "⬅️ 返回列表", callback_data: "page:" + page}]);
  var text = "🖥 <b>" + html(title(item)) + "</b> <code>#" + html(item.id) + "</code>\n" + (item.remark ? "📝 备注：" + html(item.remark) + "\n" : "") + "\n📡 状态：" + state(item.status) + "\n🧠 CPU：" + html(item.cpu) + " vCPU\n💾 内存：" + html(item.memory) + " MB\n🌐 地址：<code>" + html(item.ip_address || item.ipv6_address || "暂无") + "</code>\n📅 到期：" + html(date(item.expire_at));
  // traffic_total 为 0 表示不限流量
  if (typeof item.traffic_used === "number") text += "\n📊 流量：" + item.traffic_used.toFixed(1) + " GB / " + (item.traffic_total ? item.traffic_total.toFixed(1) + " GB" : "不限");
  reply(external, text, rows, messageId);
}
// 保存一分钟内有效的确认凭证，返回确认和取消按钮。
function confirmButtons(external, pending, okText) {
  pending.token = crypto.randomHex(16);
  pending.expires = Date.now() + 60000;
  novaix.storage.set("confirm:" + external, pending);
  return [[{text: okText, callback_data: pending.token}, {text: "✖️ 取消", callback_data: "cancel:" + pending.token}]];
}
function confirmAction(external, id, action, page, messageId) {
  var instance = novaix.instances.get(external, id);
  var label = ACTIONS[action];
  if (action === "start" ? instance.status !== "stopped" : instance.status !== "running") {
    reply(external, "⚠️ <b>当前状态无法" + label + "</b>\n服务器状态：" + state(instance.status), [[{text: "⬅️ 返回详情", callback_data: "view:" + id + ":" + page}]], messageId);
    return;
  }
  reply(external, "⚠️ <b>确认" + label + "服务器？</b>\n\n🖥 " + html(title(instance)) + " <code>#" + html(instance.id) + "</code>\n⏱ 请在 1 分钟内确认。", confirmButtons(external, {id: id, action: action, page: page}, "✅ 确认" + label), messageId);
}
function confirmUnbind(external, messageId) {
  reply(external, "🔓 <b>确认解除账号绑定？</b>\n解除后机器人将无法查询或操作您的服务器。", confirmButtons(external, {action: "unbind"}, "确认解除"), messageId);
}
function handleMessage(external, text) {
  var parts = text.trim().split(/\s+/);
  var command = parts[0].split("@")[0];
  var id = positive(parts[1]);
  if (command === "/start" || command === "/menu") {
    showMenu(external);
  } else if (command === "/help") {
    showHelp(external);
  } else if (command === "/connect") {
    novaix.storage.delete("confirm:" + external);
    novaix.accounts.bind(external, parts[1] || "");
    reply(external, "✅ <b>绑定成功</b>\n点击下方按钮查看您的云服务器。", [[{text: "🖥 我的服务器", callback_data: "page:1"}]]);
  } else if (command === "/unbind") {
    confirmUnbind(external);
  } else if (command === "/servers" || command === "/server") {
    var page = parts[1] ? id : 1;
    if (!page) return reply(external, "请输入正确的页码，例如 <code>/servers 2</code>。");
    showServers(external, page);
  } else if (command === "/status") {
    if (!id) return reply(external, "请输入正确的实例 ID，例如 <code>/status 123</code>。");
    showInstance(external, id, 1);
  } else if (command === "/startvm" || command === "/stop" || command === "/restart") {
    if (!id) return reply(external, "请输入正确的实例 ID，例如 <code>" + command + " 123</code>。");
    confirmAction(external, id, command === "/startvm" ? "start" : command.slice(1), 1);
  } else {
    reply(external, "❔ <b>未知指令</b>\n点击下方按钮打开主菜单。", [[{text: "🏠 打开主菜单", callback_data: "menu"}]]);
  }
}
// 返回需要在按钮应答中提示的文字，无需提示时不返回。
function handleCallback(external, callback) {
  var data = typeof callback.data === "string" ? callback.data : "";
  var parts = data.split(":");
  var messageId = callback.message.message_id;
  if (data === "menu") return showMenu(external, messageId);
  if (data === "help") return showHelp(external, messageId);
  if (data === "unbind") return confirmUnbind(external, messageId);
  if (parts[0] === "page" && positive(parts[1])) return showServers(external, positive(parts[1]), messageId);
  // 任务通知中的 open 按钮发送新消息，保留原通知。
  if ((parts[0] === "view" || parts[0] === "open") && positive(parts[1]) && positive(parts[2])) return showInstance(external, positive(parts[1]), positive(parts[2]), parts[0] === "view" ? messageId : undefined);
  if (parts[0] === "action" && ACTIONS[parts[1]] && positive(parts[2]) && positive(parts[3])) return confirmAction(external, positive(parts[2]), parts[1], positive(parts[3]), messageId);
  var pending = novaix.storage.get("confirm:" + external);
  if (!pending || (pending.token !== data && "cancel:" + pending.token !== data) || pending.expires < Date.now()) return "⏱ 操作已失效，请重新发送指令。";
  // 先消费确认信息，即使回复失败重试也不会重复提交电源操作。
  novaix.storage.delete("confirm:" + external);
  if (data.indexOf("cancel:") === 0) {
    if (pending.action === "unbind") showMenu(external, messageId);
    else showInstance(external, pending.id, pending.page, messageId);
    return "已取消";
  }
  if (pending.action === "unbind") {
    novaix.accounts.unbind(external);
    reply(external, "🔓 <b>已解除绑定</b>\n如需重新连接，请在客户中心生成新的配对码。", [MENU_ROW], messageId);
    return;
  }
  var job = novaix.instances.action(external, pending.id, pending.action);
  reply(external, "🚀 <b>操作已提交</b>\n任务编号：<code>" + html(job.task_id) + "</code>\n完成后会向您发送通知。", [[{text: "🖥 返回服务器", callback_data: "view:" + pending.id + ":" + pending.page}]], messageId);
}
function onEvent(event) {
  reply(event.external_id, (event.status === "completed" ? "✅ <b>任务已完成</b>" : "❌ <b>任务执行失败</b>") + "\n🖥 服务器：<code>#" + html(event.instance_id) + "</code>\n📋 任务编号：<code>" + html(event.task_id) + "</code>" + (event.status === "completed" ? "" : "\n请在控制台查看详情。"), [[{text: "🖥 查看服务器", callback_data: "open:" + event.instance_id + ":1"}]]);
}
