// 短信宝插件
// 对接文档: https://www.smsbao.com/openapi/

var statusMessages = {
  "30": "密码/ApiKey 错误",
  "40": "账号不存在",
  "41": "余额不足",
  "43": "IP 地址受限",
  "50": "内容含敏感词",
  "51": "手机号格式错误"
};

function send(phone, params) {
  var content = config.template || "您的验证码是{code}，5分钟内有效。";
  for (var k in params) {
    content = content.split("{" + k + "}").join(params[k]);
  }
  content = "【" + config.sign + "】" + content;

  var query = url.buildQuery({
    u: config.username,
    p: config.apikey,
    m: phone,
    c: content
  });

  var resp = http.request("GET", "https://api.smsbao.com/sms?" + query, {
    timeout: 10
  });

  if (resp.status !== 200) {
    throw new Error("短信宝接口返回异常状态码 " + resp.status);
  }

  var code = resp.body.trim();
  if (code !== "0") {
    var msg = statusMessages[code] || "未知错误（错误码 " + code + "）";
    throw new Error("短信宝发送失败: " + msg);
  }
}
