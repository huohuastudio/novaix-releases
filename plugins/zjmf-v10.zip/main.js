// 魔方业务系统 V10 供应商插件（魔方云 mf_cloud 模块，最低支持 10.4.6）
//
// 上游约定：
// - 统一返回 {status, msg, data}，HTTP 状态恒为 200：status 200 成功、400 失败、401 未授权；
// - 请求体为 application/x-www-form-urlencoded，嵌套参数写作 config_options[cpu]=2；
// - 同 IP、同地址、同参数的 POST/PUT 在 3 秒内重复提交会被拒绝（实例操作 remf_cloud 除外），
//   清单因此声明 min_interval_ms=3000，插件把"重复提交"视为结果未知而不是失败。
//
// 下单沿用官方下游流程：清空购物车（按 downstream_token 做幂等检查）→ 加入购物车 → 结算 → 余额支付，
// 每完成一步写入检查点。ctx.service.reference 作为 downstream_token，同时写入主机备注（notes）便于反查。
// 插件不保存任何状态，跨调用的信息只通过检查点与 novaix.cache 传递。

var PAGE_SIZE = 20;
var JWT_TTL = 7000; // 上游 JWT 有效期 7200 秒，提前失效
var LIST_TTL = 300;
var MAX_SCAN_PAGES = 20;

var ACTION_LABELS = {
  on: "开机",
  off: "关机",
  reboot: "重启",
  hard_off: "强制关机",
  hard_reboot: "强制重启",
  reset_password: "重置密码",
  reinstall: "重装系统"
};

// ---------- 通用工具 ----------

function str(v) {
  return v === undefined || v === null ? "" : String(v);
}

function num(v) {
  var n = Number(v);
  return isFinite(n) ? n : 0;
}

// 上游金额（元）转为分
function toCents(v) {
  var n = parseFloat(v);
  return isFinite(n) ? Math.round(n * 100) : 0;
}

function yuan(cents) {
  return (cents / 100).toFixed(2);
}

function nowUnix() {
  return Math.floor(Date.now() / 1000);
}

function assign(target, extra) {
  if (extra) {
    for (var k in extra) {
      if (extra[k] !== undefined) target[k] = extra[k];
    }
  }
  return target;
}

// 编码为 PHP 风格的 form-urlencoded：对象展开为 key[sub]=v，数组展开为 key[]=v
function encodeForm(params) {
  var parts = [];
  function add(key, v) {
    if (v === undefined || v === null) return;
    if (Array.isArray(v)) {
      for (var i = 0; i < v.length; i++) add(key + "[]", v[i]);
      return;
    }
    if (typeof v === "object") {
      for (var k in v) add(key + "[" + k + "]", v[k]);
      return;
    }
    parts.push(url.encode(key) + "=" + url.encode(String(v)));
  }
  for (var k in params) add(k, params[k]);
  return parts.join("&");
}

// keyvalue 字段的值为 JSON 对象字符串
function parseKeyValue(raw) {
  if (!raw) return {};
  if (typeof raw === "object") return raw;
  try {
    var v = JSON.parse(raw);
    return v && typeof v === "object" && !Array.isArray(v) ? v : {};
  } catch (e) {
    return {};
  }
}

function randomPassword() {
  return "Nv" + crypto.randomHex(5) + "Q" + crypto.randomHex(3);
}

// 一次返回全量的列表：本地按关键字过滤并分页
function localPage(items, page, keyword) {
  var kw = str(keyword).trim().toLowerCase();
  var list = items;
  if (kw) {
    list = [];
    for (var i = 0; i < items.length; i++) {
      var text = (items[i].label + " " + str(items[i].description) + " " + items[i].value).toLowerCase();
      if (text.indexOf(kw) >= 0) list.push(items[i]);
    }
  }
  var start = (page - 1) * PAGE_SIZE;
  return { items: list.slice(start, start + PAGE_SIZE), has_more: start + PAGE_SIZE < list.length };
}

// 将周期名称（如"1个月""3个月""1年""季付"）换算为月数
function durationMonths(name) {
  var s = str(name);
  var m = s.match(/(\d+)\s*个?月/);
  if (m) return Number(m[1]);
  m = s.match(/(\d+)\s*年/);
  if (m) return Number(m[1]) * 12;
  if (/半年/.test(s)) return 6;
  if (/季/.test(s)) return 3;
  if (/年/.test(s)) return 12;
  if (/月/.test(s)) return 1;
  return 0;
}

var CYCLE_MONTHS = { monthly: 1, quarterly: 3, yearly: 12 };

// ---------- 结果构造 ----------

function upstreamError(code, message) {
  var e = new Error(message);
  e.code = code;
  return e;
}

function errorMessage(e) {
  if (!e) return "未知错误";
  return str(e.message) || String(e);
}

function errorCode(e) {
  if (e && typeof e.code === "string" && e.code) return e.code;
  return /timeout|deadline|超时/i.test(errorMessage(e)) ? "timeout" : "upstream_error";
}

function succeeded(extra) {
  return assign({ status: "succeeded" }, extra);
}

function pending(retryAfter, extra) {
  return assign({ status: "pending", retry_after: retryAfter }, extra);
}

function failed(code, message, retryable, extra) {
  return assign({ status: "failed", error: { code: code, message: message, retryable: !!retryable } }, extra);
}

function unknown(code, message, extra) {
  return assign({ status: "unknown", error: { code: code, message: message } }, extra);
}

function unknownFrom(e, extra) {
  return unknown(errorCode(e), "上游结果未知：" + errorMessage(e), extra);
}

// 调用尚未产生副作用时出错：可安全重试（鉴权与参数错误除外）
function failedBeforeSubmit(e) {
  var code = errorCode(e);
  return failed(code, "调用上游失败：" + errorMessage(e), code !== "auth" && code !== "invalid_params");
}

// 按上游提示归类错误码
function classify(resp) {
  var msg = str(resp && resp.msg);
  if (resp && resp.status === 404) return "unsupported";
  if (resp && resp.status === 401) return "auth";
  if (/余额不足|余额不够|insufficient/i.test(msg)) return "insufficient_balance";
  if (/库存|售罄|缺货|sold\s*out/i.test(msg)) return "out_of_stock";
  if (/重复|频繁|稍后再试|too\s*many/i.test(msg)) return "rate_limited";
  return "upstream_error";
}

// 上游明确拒绝：重复提交时前一次相同请求可能已执行，按结果未知处理
function rejected(resp, prefix, extra) {
  var code = classify(resp);
  if (code === "rate_limited") return unknown(code, prefix + "，上游提示重复提交，结果未知：" + resp.msg, extra);
  return failed(code, prefix + "：" + resp.msg, false, extra);
}

// ---------- HTTP 与鉴权 ----------

function baseURL(ctx) {
  var u = str(ctx.connection && ctx.connection.url).trim().replace(/\/+$/, "");
  if (!/^https?:\/\//i.test(u)) throw upstreamError("invalid_params", "接口地址必须以 http:// 或 https:// 开头");
  return u;
}

// 令牌缓存键包含账号与密钥摘要：修改连接配置后不会复用旧令牌
function tokenKey(ctx) {
  var user = str(ctx.connection.username).trim().toLowerCase();
  return "jwt:" + user + "@" + baseURL(ctx) + "#" + crypto.sha256(user + "\n" + str(ctx.connection.api_key)).slice(0, 16);
}

function send(ctx, method, path, params, token) {
  var target = baseURL(ctx) + path;
  var headers = { Accept: "application/json" };
  if (token) headers.Authorization = "Bearer " + token;
  var form = encodeForm(params || {});
  var body;
  if (method === "GET") {
    if (form) target += (target.indexOf("?") >= 0 ? "&" : "?") + form;
  } else {
    body = form;
    headers["Content-Type"] = "application/x-www-form-urlencoded";
  }
  var resp = http.request(method, target, { headers: headers, body: body, timeout: 30 });
  if (resp.status === 401) return { status: 401, msg: "未授权" };
  if (resp.status === 404) return { status: 404, msg: "上游接口不存在（HTTP 404）" };
  if (resp.status >= 500) throw upstreamError("upstream_error", "上游服务异常（HTTP " + resp.status + "）");
  var data;
  try {
    data = JSON.parse(resp.body);
  } catch (e) {
    throw upstreamError("upstream_error", "上游返回了无法解析的响应（HTTP " + resp.status + "）");
  }
  if (!data || typeof data !== "object") throw upstreamError("upstream_error", "上游响应格式错误");
  data.status = Number(data.status);
  data.msg = str(data.msg || data.message);
  return data;
}

function login(ctx) {
  var user = str(ctx.connection.username).trim();
  var key = str(ctx.connection.api_key);
  if (!user || !key) throw upstreamError("auth", "请填写上游账号与 API 密钥");
  var resp = send(ctx, "POST", "/api/v1/auth", { username: user, password: key }, "");
  var jwt = resp.data && resp.data.jwt;
  if (resp.status !== 200 || !jwt) throw upstreamError("auth", "上游登录失败：" + (resp.msg || "未返回令牌"));
  novaix.cache.set(tokenKey(ctx), String(jwt), JWT_TTL);
  return String(jwt);
}

function currentToken(ctx) {
  var t = novaix.cache.get(tokenKey(ctx));
  return t ? String(t) : login(ctx);
}

// 带鉴权的请求：遇到 401 清除缓存的令牌并重新登录一次（401 表示请求未被执行，可安全重发）
function api(ctx, method, path, params) {
  var resp = send(ctx, method, path, params, currentToken(ctx));
  if (resp.status === 401) {
    novaix.cache.delete(tokenKey(ctx));
    resp = send(ctx, method, path, params, login(ctx));
    if (resp.status === 401) throw upstreamError("auth", "上游鉴权失败：" + resp.msg);
  }
  return resp;
}

// ---------- 上下文 ----------

function svc(ctx) {
  return ctx.service || {};
}

function opInfo(ctx) {
  return ctx.operation || {};
}

function checkpointOf(ctx) {
  var cp = ctx.operation && ctx.operation.checkpoint;
  return cp && typeof cp === "object" ? JSON.parse(JSON.stringify(cp)) : {};
}

function saveCheckpoint(ctx, cp) {
  novaix.checkpoint(cp);
  if (ctx.operation) ctx.operation.checkpoint = cp;
}

function hostIdOf(ctx) {
  var id = str(svc(ctx).remote_id).trim();
  return /^\d+$/.test(id) ? id : "";
}

function productIdOf(ctx) {
  var id = str(ctx.product && ctx.product.product_id).trim();
  return /^\d+$/.test(id) ? id : "";
}

function siteURL(ctx) {
  var u = str(ctx.site && ctx.site.url).trim().replace(/\/+$/, "");
  return /^https?:\/\//i.test(u) ? u : "http://localhost";
}

// 下游标识：downstream_host_id 必须非 0、token 不能为空，否则上游的模糊匹配可能命中他人订单
function downstreamParams(ctx) {
  return { downstream_url: siteURL(ctx), downstream_token: svc(ctx).reference, downstream_host_id: svc(ctx).id };
}

function identityError(ctx) {
  var s = svc(ctx);
  if (!/^[0-9a-f]{32}$/.test(str(s.reference))) return "服务引用无效（应为 32 位小写十六进制）";
  if (!(Number(s.id) > 0)) return "服务 ID 无效";
  return "";
}

// ---------- 商品与选项 ----------

function cached(key, loader) {
  var v = novaix.cache.get(key);
  if (v !== null && v !== undefined) return v;
  v = loader();
  novaix.cache.set(key, v, LIST_TTL);
  return v;
}

function productOptions(ctx, page, keyword) {
  var params = { page: page, limit: PAGE_SIZE };
  if (keyword) params.keywords = keyword;
  var resp = api(ctx, "GET", "/api/v1/product", params);
  if (resp.status !== 200) throw upstreamError(classify(resp), "获取上游商品失败：" + resp.msg);
  var d = resp.data || {};
  var list = d.list || d.product || [];
  var items = [];
  for (var i = 0; i < list.length; i++) {
    var p = list[i];
    var desc = p.price !== undefined && p.price !== null && p.price !== "" ? "¥" + p.price + (p.cycle ? " / " + p.cycle : "") : "";
    items.push({ value: str(p.id), label: str(p.name) || "商品 " + p.id, description: desc });
  }
  var count = num(d.count);
  return { items: items, has_more: count > 0 ? page * PAGE_SIZE < count : list.length >= PAGE_SIZE };
}

function orderPage(ctx, pid) {
  return cached("order_page:" + pid, function () {
    var resp = api(ctx, "GET", "/console/v1/product/" + pid + "/mf_cloud/order_page", { is_downstream: 1 });
    if (resp.status !== 200) throw upstreamError(classify(resp), "获取上游商品配置失败：" + resp.msg);
    return resp.data || {};
  });
}

function recommendOptions(ctx, pid) {
  var data = orderPage(ctx, pid);
  var list = data.reommend_config || data.recommend_config || [];
  var items = [];
  for (var i = 0; i < list.length; i++) {
    var rc = list[i];
    var desc = str(rc.description);
    if (!desc && rc.cpu) desc = rc.cpu + " 核 / " + rc.memory + "GB";
    items.push({ value: str(rc.id), label: str(rc.name) || "配置 " + rc.id, description: desc });
  }
  return items;
}

function imageOptions(ctx, pid) {
  return cached("image:" + pid, function () {
    var resp = api(ctx, "GET", "/console/v1/product/" + pid + "/mf_cloud/image", { is_downstream: 1 });
    if (resp.status !== 200) throw upstreamError(classify(resp), "获取上游镜像失败：" + resp.msg);
    var groups = (resp.data && (resp.data.list || resp.data.image)) || [];
    var items = [];
    for (var i = 0; i < groups.length; i++) {
      var images = groups[i].image || [];
      for (var j = 0; j < images.length; j++) {
        items.push({ value: str(images[j].id), label: str(images[j].name), description: str(groups[i].name) });
      }
    }
    return items;
  });
}

// 上游周期列表（价格随配置变化，按配置缓存，同时避开 3 秒防重复提交）
function durations(ctx, pid, values) {
  values = values || {};
  var params = {};
  if (str(values.recommend_config_id)) params.recommend_config_id = str(values.recommend_config_id);
  if (str(values.image_id)) params.image_id = str(values.image_id);
  return cached("duration:" + pid + ":" + str(params.recommend_config_id) + ":" + str(params.image_id), function () {
    var resp = api(ctx, "POST", "/console/v1/product/" + pid + "/mf_cloud/duration", params);
    if (resp.status !== 200) throw upstreamError(classify(resp), "获取上游周期失败：" + resp.msg);
    var d = resp.data;
    return Array.isArray(d) ? d : (d && (d.list || d.duration)) || [];
  });
}

function getOptions(ctx, fieldKey, values, opts) {
  values = values || {};
  var page = Math.max(1, parseInt(opts && opts.page, 10) || 1);
  var keyword = str(opts && opts.keyword).trim();
  if (fieldKey === "product_id") return productOptions(ctx, page, keyword);
  var pid = str(values.product_id).trim();
  if (!/^\d+$/.test(pid)) return { items: [], has_more: false };
  if (fieldKey === "recommend_config_id") return localPage(recommendOptions(ctx, pid), page, keyword);
  if (fieldKey === "image_id") return localPage(imageOptions(ctx, pid), page, keyword);
  if (fieldKey === "cycle_monthly" || fieldKey === "cycle_quarterly" || fieldKey === "cycle_yearly") {
    var list = durations(ctx, pid, values);
    var items = [];
    for (var i = 0; i < list.length; i++) {
      var d = list[i];
      items.push({ value: str(d.id), label: str(d.name) + (d.price !== undefined ? "（¥" + d.price + "）" : ""), description: "" });
    }
    return localPage(items, page, keyword);
  }
  return { items: [], has_more: false };
}

// 当前服务周期对应的上游 duration_id：优先使用商品配置，未配置时按周期名称匹配
function resolveDuration(ctx) {
  var v = str(svc(ctx).cycle_param).trim();
  if (v) return v;
  var want = CYCLE_MONTHS[str(svc(ctx).billing_cycle)];
  if (want) {
    var list = durations(ctx, productIdOf(ctx), ctx.product);
    for (var i = 0; i < list.length; i++) {
      if (durationMonths(list[i].name) === want) return str(list[i].id);
    }
  }
  throw upstreamError("invalid_params", "商品未配置该计费周期对应的上游周期，且无法自动匹配");
}

function cartParams(ctx) {
  var p = ctx.product || {};
  var pid = productIdOf(ctx);
  if (!pid) throw upstreamError("invalid_params", "商品未配置上游商品");
  if (!str(p.image_id)) throw upstreamError("invalid_params", "商品未配置系统镜像");
  var cfg = {};
  var extra = parseKeyValue(p.config_options);
  for (var k in extra) cfg[k] = extra[k];
  cfg.image_id = str(p.image_id);
  cfg.duration_id = resolveDuration(ctx);
  cfg.network_type = str(p.network_type) || "normal";
  cfg.port = num(p.port) || 22;
  cfg.password = str(svc(ctx).checkout && svc(ctx).checkout.password) || randomPassword();
  cfg.notes = svc(ctx).reference;
  if (str(p.recommend_config_id)) cfg.recommend_config_id = str(p.recommend_config_id);
  return { product_id: pid, qty: 1, config_options: cfg };
}

// ---------- 主机 ----------

function isGone(status) {
  return status === "Deleted" || status === "Cancelled";
}

function dueOf(host) {
  var t = num(host && host.due_time);
  return t > 0 ? t : undefined;
}

// 查询主机详情，主机不存在时返回 null
function getHost(ctx, hostId) {
  var resp = api(ctx, "GET", "/console/v1/host/" + hostId);
  if (resp.status === 200 && resp.data && resp.data.host) return resp.data.host;
  if (resp.status === 404 || /不存在|未找到|not\s*found/i.test(resp.msg)) return null;
  throw upstreamError(classify(resp), "查询上游主机失败：" + resp.msg);
}

function cloudDetail(ctx, hostId) {
  var resp = api(ctx, "GET", "/console/v1/mf_cloud/" + hostId);
  if (resp.status !== 200 || !resp.data) throw upstreamError(classify(resp), "查询上游实例详情失败：" + resp.msg);
  return resp.data;
}

function pushField(fields, key, label, value, copyable) {
  var v = str(value).trim();
  if (v && v !== "0") fields.push({ key: key, label: label, value: v, copyable: !!copyable });
}

// 展示字段与登录密码（详情获取失败时只返回已有信息，不影响结果）
function hostInfo(ctx, hostId, host) {
  var detail = {};
  try {
    detail = cloudDetail(ctx, hostId);
  } catch (e) {
    log.warn("获取上游实例详情失败：" + errorMessage(e));
  }
  var ip = str(detail.ip || detail.dedicate_ip);
  if (!ip) {
    try {
      var r = api(ctx, "GET", "/console/v1/host/" + hostId + "/ip");
      if (r.status === 200 && r.data) ip = str(r.data.dedicate_ip || r.data.ip);
    } catch (e2) {
      log.warn("获取上游主机 IP 失败：" + errorMessage(e2));
    }
  }
  var image = detail.image || {};
  var fields = [];
  pushField(fields, "ip", "IP 地址", ip, true);
  pushField(fields, "ipv6", "IPv6 地址", detail.ipv6, true);
  pushField(fields, "port", "远程端口", detail.port, false);
  pushField(fields, "username", "用户名", detail.username, true);
  pushField(fields, "os", "操作系统", typeof image === "object" ? image.name : image, false);
  pushField(fields, "hostname", "主机名", detail.hostname || (host && host.name), false);
  var out = { fields: fields };
  if (str(detail.password)) out.secrets = { password: str(detail.password) };
  return out;
}

function hostResult(ctx, hostId, host, cp) {
  var extra = { remote_id: str(hostId) };
  if (cp.order_id) extra.remote_ref = str(cp.order_id);
  var st = str(host.status);
  if (st === "Active" || st === "Suspended") {
    var info = hostInfo(ctx, hostId, host);
    extra.fields = info.fields;
    extra.secrets = info.secrets;
    extra.expire_at = dueOf(host);
    if (typeof cp.amount === "number" && cp.amount >= 0) extra.cost = cp.amount;
    return succeeded(extra);
  }
  if (st === "Pending" || st === "Unpaid") return pending(30, extra);
  if (st === "Failed") return unknown("upstream_error", "上游开通失败（订单已付款），请联系上游处理后人工核对", extra);
  return unknown("upstream_error", "上游主机状态异常：" + st, extra);
}

// 从订单详情中取主机 ID（结算响应丢失时使用），失败时返回空串
function hostFromOrder(ctx, orderId) {
  if (!/^\d+$/.test(str(orderId))) return "";
  try {
    var resp = api(ctx, "GET", "/console/v1/order/" + orderId);
    if (resp.status !== 200 || !resp.data) return "";
    var order = resp.data.order || resp.data;
    var items = order.items || order.order_item || [];
    for (var i = 0; i < items.length; i++) {
      if (num(items[i].host_id) > 0) return str(items[i].host_id);
    }
    if (Array.isArray(order.host_ids) && order.host_ids.length) return str(order.host_ids[0]);
  } catch (e) {
    log.warn("查询上游订单详情失败：" + errorMessage(e));
  }
  return "";
}

// 按备注（reference）分页搜索主机：先按关键字搜索，未命中再逐页扫描，各最多 20 页
function findHostByNotes(ctx) {
  var ref = svc(ctx).reference;
  var passes = [{ keywords: ref }, {}];
  for (var p = 0; p < passes.length; p++) {
    for (var page = 1; page <= MAX_SCAN_PAGES; page++) {
      var resp = api(ctx, "GET", "/console/v1/host", assign({ page: page, limit: PAGE_SIZE }, passes[p]));
      if (resp.status !== 200) throw upstreamError(classify(resp), "搜索上游主机失败：" + resp.msg);
      var list = (resp.data && resp.data.list) || [];
      for (var i = 0; i < list.length; i++) {
        var h = list[i];
        var text = str(h.notes) + " " + str(h.client_notes) + " " + str(h.remark);
        if (text.indexOf(ref) >= 0) return str(h.id);
      }
      var count = num(resp.data && resp.data.count);
      if (list.length < PAGE_SIZE || (count > 0 && page * PAGE_SIZE >= count)) break;
    }
  }
  return "";
}

// ---------- 开通 ----------

// 订单已支付：定位主机并返回开通进度
function afterPaid(ctx, cp) {
  var hostId = str(cp.host_id || hostIdOf(ctx));
  if (!hostId && cp.order_id) hostId = hostFromOrder(ctx, cp.order_id);
  if (!hostId) {
    hostId = findHostByNotes(ctx);
    if (!hostId) return unknown("not_found", "上游订单已支付，但暂未找到对应主机", cp.order_id ? { remote_ref: str(cp.order_id) } : undefined);
  }
  if (cp.stage !== "paid" || str(cp.host_id) !== hostId) {
    cp.stage = "paid";
    cp.host_id = hostId;
    saveCheckpoint(ctx, cp);
  }
  var host = getHost(ctx, hostId);
  if (!host) return unknown("not_found", "上游主机 " + hostId + " 不存在");
  return hostResult(ctx, hostId, host, cp);
}

// 开通流程（可重入）：create 可新建订单；lookup / query 只续做已有订单，确认不存在时返回 not_found
function provision(ctx, mode) {
  var bad = identityError(ctx);
  if (bad) return mode === "create" ? failed("invalid_params", bad, false) : unknown("invalid_params", bad);
  var cp = checkpointOf(ctx);
  // 重入时此前可能已提交结算或支付：任何异常都只能按结果未知处理
  var risky = mode !== "create" || (!!cp.stage && cp.stage !== "cleared");
  try {
    // 已付款：直接查询主机
    var knownId = str(cp.host_id || hostIdOf(ctx));
    if (knownId && (cp.stage === "paid" || hostIdOf(ctx))) {
      var known = getHost(ctx, knownId);
      if (!known) return unknown("not_found", "上游主机 " + knownId + " 不存在");
      if (known.status !== "Unpaid") return hostResult(ctx, knownId, known, cp);
    }

    // 1. 清空购物车，同时按下游标识检查是否已有订单
    var ds = downstreamParams(ctx);
    var clear = api(ctx, "DELETE", "/console/v1/cart", ds);
    if (clear.status !== 200) {
      if (/已开通|已支付/.test(clear.msg)) {
        risky = true;
        return afterPaid(ctx, cp);
      }
      var cc = classify(clear);
      if (mode === "create" && cc !== "rate_limited") return failed(cc, "清空上游购物车失败：" + clear.msg, true);
      return unknown(cc, "清空上游购物车失败：" + clear.msg);
    }
    var existing = clear.data && clear.data.order_id ? str(clear.data.order_id) : "";
    var skipPay = false;
    if (existing) {
      novaix.note("上游已存在该服务的未支付订单 " + existing + "，继续支付");
      cp.stage = "settled";
      cp.order_id = existing;
      saveCheckpoint(ctx, cp);
    } else {
      if (mode !== "create") return failed("not_found", "上游未找到该服务的订单");
      cp = { stage: "cleared" };
      saveCheckpoint(ctx, cp);

      // 2. 加入购物车
      var cart = api(ctx, "POST", "/console/v1/cart", cartParams(ctx));
      if (cart.status !== 200) {
        var cartCode = classify(cart);
        return failed(cartCode, "加入上游购物车失败：" + cart.msg, cartCode === "rate_limited");
      }
      cp.stage = "carted";
      saveCheckpoint(ctx, cp);

      // 3. 结算生成订单
      risky = true;
      var settle = api(ctx, "POST", "/console/v1/cart/settle", assign({ positions: [0] }, ds));
      if (settle.status !== 200) return rejected(settle, "上游结算失败");
      var sd = settle.data || {};
      var hostIds = sd.host_ids || sd.host_id || [];
      if (!Array.isArray(hostIds)) hostIds = [hostIds];
      cp = { stage: "settled", order_id: str(sd.order_id || sd.id), host_id: hostIds.length ? str(hostIds[0]) : "" };
      if (sd.amount !== undefined && sd.amount !== null) {
        cp.amount = toCents(sd.amount);
        skipPay = cp.amount === 0; // 0 元订单结算即支付
      }
      saveCheckpoint(ctx, cp);
      if (!cp.order_id) return unknown("upstream_error", "上游结算未返回订单号");
    }

    // 4. 余额支付
    if (!skipPay) {
      risky = true;
      var pay = api(ctx, "POST", "/console/v1/pay", { id: cp.order_id, gateway: "credit" });
      if (pay.status !== 200 && !/已支付|已付款/.test(pay.msg)) {
        return rejected(pay, classify(pay) === "insufficient_balance" ? "上游余额不足" : "上游支付失败", { remote_ref: str(cp.order_id) });
      }
    }
    cp.stage = "paid";
    saveCheckpoint(ctx, cp);
    return afterPaid(ctx, cp);
  } catch (e) {
    if (!risky) return failedBeforeSubmit(e);
    return unknownFrom(e, cp.order_id ? { remote_ref: str(cp.order_id) } : undefined);
  }
}

// ---------- 续费 ----------

function pickRenewOption(ctx, data) {
  var list = Array.isArray(data) ? data : (data && (data.host || data.list || data.duration)) || [];
  if (!list.length) return null;
  var param = str(svc(ctx).cycle_param).trim();
  var i;
  if (param) {
    for (i = 0; i < list.length; i++) {
      if (str(list[i].id) === param || str(list[i].duration_id) === param) return list[i];
    }
    // 续费列表没有周期 ID 时，按商品周期名称匹配
    try {
      var durs = durations(ctx, productIdOf(ctx), ctx.product);
      for (var j = 0; j < durs.length; j++) {
        if (str(durs[j].id) !== param) continue;
        for (i = 0; i < list.length; i++) {
          if (str(list[i].billing_cycle) === str(durs[j].name)) return list[i];
        }
      }
    } catch (e) {
      log.warn("获取上游周期失败：" + errorMessage(e));
    }
  }
  var want = CYCLE_MONTHS[str(svc(ctx).billing_cycle)];
  if (want) {
    for (i = 0; i < list.length; i++) {
      var months = durationMonths(list[i].billing_cycle) || Math.round(num(list[i].duration) / (30 * 86400));
      if (months === want) return list[i];
    }
  }
  return null;
}

function renewDone(host, cp) {
  var extra = { expire_at: dueOf(host) };
  if (cp.order_id) extra.remote_ref = str(cp.order_id);
  if (num(cp.price) > 0) extra.cost = num(cp.price);
  return succeeded(extra);
}

function renewCheck(ctx, hostId, cp) {
  var host = getHost(ctx, hostId);
  if (host && num(host.due_time) > num(cp.old_due)) return renewDone(host, cp);
  return pending(15, cp.order_id ? { remote_ref: str(cp.order_id) } : undefined);
}

function payRenew(ctx, hostId, cp) {
  var pay = api(ctx, "POST", "/console/v1/pay", { id: cp.order_id, gateway: "credit" });
  if (pay.status !== 200 && !/已支付|已付款/.test(pay.msg)) {
    return rejected(pay, classify(pay) === "insufficient_balance" ? "上游余额不足" : "上游续费订单支付失败", { remote_ref: str(cp.order_id) });
  }
  cp.stage = "renew_paid";
  saveCheckpoint(ctx, cp);
  return renewCheck(ctx, hostId, cp);
}

// 续费不幂等：提交前在检查点记录旧到期时间，重入或查询时以到期时间是否前移判断，绝不重复提交
function renewFlow(ctx, isQuery) {
  var hostId = hostIdOf(ctx);
  if (!hostId) return isQuery ? unknown("invalid_params", "缺少上游主机 ID") : failed("invalid_params", "缺少上游主机 ID", false);
  var cp = checkpointOf(ctx);
  var risky = isQuery || cp.old_due !== undefined;
  try {
    var host = getHost(ctx, hostId);
    if (!host) return isQuery ? unknown("not_found", "上游主机不存在") : failed("not_found", "上游主机不存在", false);
    var due = num(host.due_time);
    if (cp.old_due !== undefined) {
      if (due > num(cp.old_due)) return renewDone(host, cp);
      if (cp.order_id) {
        risky = true;
        return payRenew(ctx, hostId, cp);
      }
      return unknown("upstream_error", "此前提交的续费结果未知且到期时间未变化，请核对上游续费订单");
    }
    if (isQuery) return failed("upstream_error", "续费请求尚未提交", true);
    if (host.status !== "Active" && host.status !== "Suspended") {
      return failed("upstream_error", "上游主机状态为 " + host.status + "，无法续费", false);
    }
    var page = api(ctx, "GET", "/console/v1/host/" + hostId + "/renew");
    if (page.status !== 200) return failed(classify(page), "获取上游续费周期失败：" + page.msg, false);
    var opt = pickRenewOption(ctx, page.data);
    if (!opt) return failed("invalid_params", "无法匹配上游续费周期", false);

    cp = { stage: "renew_submitted", old_due: due, billing_cycle: str(opt.billing_cycle), price: toCents(opt.price) };
    saveCheckpoint(ctx, cp);
    risky = true;
    var resp = api(ctx, "POST", "/console/v1/host/" + hostId + "/renew", { billing_cycle: opt.billing_cycle });
    if (resp.status !== 200) {
      // 上游明确拒绝（未生成订单）时清除检查点，允许重新提交
      if (classify(resp) !== "rate_limited") saveCheckpoint(ctx, {});
      return rejected(resp, "上游续费失败");
    }
    var d = resp.data || {};
    var code = str(d.code || resp.code);
    var orderId = str(d.id || d.order_id);
    if (code !== "Paid" && orderId) {
      cp.stage = "renew_ordered";
      cp.order_id = orderId;
      saveCheckpoint(ctx, cp);
      return payRenew(ctx, hostId, cp);
    }
    if (orderId) cp.order_id = orderId;
    cp.stage = "renew_paid";
    saveCheckpoint(ctx, cp);
    return renewCheck(ctx, hostId, cp);
  } catch (e) {
    if (!risky) return failedBeforeSubmit(e);
    return unknownFrom(e);
  }
}

// ---------- 暂停 / 恢复 / 退订 ----------

function suspend(ctx) {
  var hostId = hostIdOf(ctx);
  if (!hostId) return failed("invalid_params", "缺少上游主机 ID", false);
  var expired = str((opInfo(ctx).input || {}).reason) === "expired";
  try {
    var resp = api(ctx, "POST", "/console/v1/host/" + hostId + "/module/suspend", {
      suspend_type: expired ? "overdue" : "other",
      suspend_reason: expired ? "到期未续费" : "下游暂停"
    });
    if (resp.status === 200 || /已暂停|已经暂停/.test(resp.msg)) return succeeded();
    return rejected(resp, "上游暂停失败");
  } catch (e) {
    return unknownFrom(e);
  }
}

function unsuspend(ctx) {
  var hostId = hostIdOf(ctx);
  if (!hostId) return failed("invalid_params", "缺少上游主机 ID", false);
  try {
    var resp = api(ctx, "POST", "/console/v1/host/" + hostId + "/module/unsuspend", {});
    if (resp.status === 200 || /未暂停|已激活|已恢复/.test(resp.msg)) return succeeded();
    return rejected(resp, "上游解除暂停失败");
  } catch (e) {
    return unknownFrom(e);
  }
}

function statusQuery(ctx, want, label) {
  var hostId = hostIdOf(ctx);
  if (!hostId) return unknown("invalid_params", "缺少上游主机 ID");
  try {
    var host = getHost(ctx, hostId);
    if (!host) return unknown("not_found", "上游主机不存在");
    if (str(host.status) === want) return succeeded({ expire_at: dueOf(host) });
    if (isGone(str(host.status))) return unknown("upstream_error", "上游主机已删除");
    // 暂停/解除暂停为同步接口：状态未变化说明上游没有执行
    return failed("upstream_error", "上游主机状态为 " + host.status + "，" + label + "未生效", true);
  } catch (e) {
    return unknownFrom(e);
  }
}

// ---------- 退订（停用申请） ----------
//
// 上游 idcsmart_refund 插件的停用申请状态：Pending 待审核、Suspending 待停用、Suspend 停用中、
// Suspended 已停用、Refund 已退款、Reject 审核驳回、Cancelled 已取消。
// 立即停用申请由上游每日任务执行，执行后主机变为 Suspended（不会删除），因此退订是否完成
// 只能以停用申请状态为准，不能用主机状态推断（主机可能在申请前就因到期而暂停）。

var REFUND_DONE = { Suspended: true, Refund: true };
var REFUND_OPEN = { Pending: true, Suspending: true, Suspend: true };

// 主机最新一条停用申请，没有申请时返回 null
function latestRefund(ctx, hostId) {
  var resp = api(ctx, "GET", "/console/v1/refund/host/" + hostId + "/refund");
  if (resp.status === 200) return (resp.data && resp.data.refund) || null;
  throw upstreamError(classify(resp), "查询上游停用申请失败：" + resp.msg);
}

// 按停用申请状态返回退订结果
function refundResult(rf, host) {
  var st = str(rf.status);
  if (REFUND_DONE[st]) {
    // 上游执行停用后会把主机置为 Suspended；申请已完成但主机仍可用，说明上游被人工恢复过，需要核对
    if (str(host.status) !== "Suspended") {
      return failed("upstream_error", "上游停用申请已完成，但主机状态为 " + str(host.status) + "，请人工核对", false);
    }
    novaix.note("上游停用申请 #" + str(rf.id) + " 已完成（" + st + "）");
    return succeeded();
  }
  if (st === "Pending") {
    novaix.note("上游停用申请 #" + str(rf.id) + " 待上游审核");
    return pending(600);
  }
  if (REFUND_OPEN[st]) return pending(600);
  if (st === "Reject") {
    return failed("upstream_error", "上游驳回了停用申请" + (str(rf.reject_reason) ? "：" + str(rf.reject_reason) : ""), false);
  }
  if (st === "Cancelled") return failed("upstream_error", "上游停用申请已被取消", false);
  return pending(600);
}

// refundReason 按上游停用原因配置组织 suspend_reason：允许自定义原因时传文本，否则传原因 ID 数组
// （优先使用连接中配置的原因 ID，未配置时取上游第一个原因）
function refundReason(ctx, hostId) {
  var resp = api(ctx, "GET", "/console/v1/refund", { host_id: hostId });
  if (resp.status !== 200 || !resp.data) throw upstreamError(classify(resp), "读取上游停用原因配置失败：" + resp.msg);
  if (num(resp.data.reason_custom) === 1) return "下游退订";
  var reasons = resp.data.reasons || [];
  var want = str(ctx.connection && ctx.connection.refund_reason_id).trim();
  for (var i = 0; i < reasons.length; i++) {
    if (!want || str(reasons[i].id) === want) return [num(reasons[i].id)];
  }
  if (want) throw upstreamError("invalid_params", "连接中配置的停用原因 ID " + want + " 在上游不存在");
  throw upstreamError("invalid_params", "上游未开放自定义停用原因，且没有可选的停用原因");
}

// resuspend 为提交停用申请而临时解除暂停的主机，提交后恢复暂停（尽力而为：失败时上游每日任务执行停用时仍会暂停）
function resuspend(ctx, hostId, cp) {
  if (!cp.resuspend || cp.resuspended) return;
  try {
    var resp = api(ctx, "POST", "/console/v1/host/" + hostId + "/module/suspend", {
      suspend_type: cp.prev_suspend_type || "other",
      suspend_reason: "下游退订"
    });
    if (resp.status === 200) {
      cp.resuspended = true;
      saveCheckpoint(ctx, cp);
      novaix.note("停用申请已提交，已恢复上游主机的暂停状态");
      return;
    }
    novaix.note("恢复上游主机暂停失败（上游执行停用时会再次暂停）：" + resp.msg);
  } catch (e) {
    novaix.note("恢复上游主机暂停失败（上游执行停用时会再次暂停）：" + errorMessage(e));
  }
}

// 退订：提交立即停用申请，由上游每日任务执行，因此返回 pending。
// 上游只接受 Pending、Active 主机的申请；到期暂停或人工暂停的主机先临时解除暂停，提交后恢复暂停
function terminate(ctx) {
  var hostId = hostIdOf(ctx);
  if (!hostId) return failed("invalid_params", "缺少上游主机 ID", false);
  var cp = checkpointOf(ctx);
  var risky = false;
  try {
    var host = getHost(ctx, hostId);
    if (!host || isGone(str(host.status))) return succeeded();
    // 先看已有申请：进行中的直接沿用（可能是上次提交但响应丢失），已完成的说明上游已停用
    var rf = latestRefund(ctx, hostId);
    if (rf && (REFUND_OPEN[str(rf.status)] || REFUND_DONE[str(rf.status)])) {
      cp = assign(cp, { stage: "refund_submitted", requested_at: cp.requested_at || nowUnix(), after_id: num(rf.id) - 1 });
      saveCheckpoint(ctx, cp);
      if (REFUND_OPEN[str(rf.status)]) resuspend(ctx, hostId, cp);
      return refundResult(rf, host);
    }
    var st = str(host.status);
    if (st !== "Pending" && st !== "Active" && st !== "Suspended") {
      return failed("upstream_error", "上游主机状态为 " + st + "，上游不接受停用申请，请到上游处理", false);
    }
    if (st === "Suspended" && str(host.suspend_type) === "upstream") {
      return failed("upstream_error", "上游主机被其上游暂停，无法解除暂停并提交停用申请，请到上游处理", false);
    }
    var reason = refundReason(ctx, hostId);
    if (st === "Suspended") {
      cp = { stage: "unsuspending", resuspend: true, prev_suspend_type: str(host.suspend_type) === "overdue" ? "overdue" : "other" };
      saveCheckpoint(ctx, cp);
      var u = api(ctx, "POST", "/console/v1/host/" + hostId + "/module/unsuspend", {});
      if (u.status !== 200) {
        saveCheckpoint(ctx, {});
        return rejected(u, "上游主机处于暂停状态，解除暂停失败，无法提交停用申请");
      }
      novaix.note("上游只接受可用状态主机的停用申请，已临时解除暂停");
    }
    // after_id 记录提交前最新申请 ID，查询时只认更新的申请，避免把旧的驳回或取消记录当作本次结果
    cp = assign({}, { stage: "refund_submitted", requested_at: nowUnix(), after_id: rf ? num(rf.id) : 0,
      resuspend: cp.resuspend, prev_suspend_type: cp.prev_suspend_type });
    saveCheckpoint(ctx, cp);
    risky = true;
    var resp = api(ctx, "POST", "/console/v1/refund", { host_id: hostId, type: "Immediate", suspend_reason: reason });
    if (resp.status === 200 || /已申请|已存在|退款中|审核中/.test(resp.msg)) {
      novaix.note("已向上游提交立即停用申请，等待上游每日任务执行");
      resuspend(ctx, hostId, cp);
      return pending(300);
    }
    if (/已删除|已取消/.test(resp.msg)) return succeeded();
    var prefix = "上游退订申请失败";
    if (classify(resp) !== "rate_limited") {
      // 申请被拒：已临时解除暂停的主机恢复暂停
      resuspend(ctx, hostId, cp);
      if (cp.resuspend && !cp.resuspended) prefix += "（上游主机已被临时解除暂停且未能恢复，请到上游手动暂停）";
      saveCheckpoint(ctx, {});
    }
    return rejected(resp, prefix);
  } catch (e) {
    if (!risky) return failedBeforeSubmit(e);
    return unknownFrom(e);
  }
}

function terminateQuery(ctx) {
  var hostId = hostIdOf(ctx);
  if (!hostId) return unknown("invalid_params", "缺少上游主机 ID");
  var cp = checkpointOf(ctx);
  try {
    var host = getHost(ctx, hostId);
    if (!host || isGone(str(host.status))) return succeeded();
    if (cp.stage !== "refund_submitted") {
      // 提交前中断（如解除暂停后服务重启）：申请确定没有提交，恢复暂停后返回失败，人工重试会重新提交
      resuspend(ctx, hostId, cp);
      return failed("upstream_error", "退订申请尚未提交（执行中断），请重试", false);
    }
    var rf = latestRefund(ctx, hostId);
    if (!rf || num(rf.id) <= num(cp.after_id)) {
      // 申请在提交接口内同步创建；短时间内查不到可能是请求仍在处理，超过后视为未提交成功
      if (nowUnix() - num(cp.requested_at) < 120) return pending(30);
      resuspend(ctx, hostId, cp);
      return failed("upstream_error", "上游没有找到本次停用申请，请确认后重试", false);
    }
    // 提交后响应丢失时尚未恢复暂停，在查询时补做
    if (REFUND_OPEN[str(rf.status)]) resuspend(ctx, hostId, cp);
    return refundResult(rf, host);
  } catch (e) {
    return unknownFrom(e);
  }
}

// ---------- 实例操作 ----------

function getActions(ctx) {
  var actions = [
    { name: "on", label: "开机" },
    { name: "off", label: "关机", confirm: "确定要关机吗？" },
    { name: "reboot", label: "重启", confirm: "确定要重启吗？" },
    { name: "hard_off", label: "强制关机", confirm: "强制关机可能导致数据丢失，确定继续吗？", danger: true },
    { name: "hard_reboot", label: "强制重启", confirm: "强制重启可能导致数据丢失，确定继续吗？", danger: true },
    {
      name: "reset_password",
      label: "重置密码",
      confirm: "确定要重置登录密码吗？",
      fields: [{ key: "password", label: "新密码", type: "password", required: true }]
    }
  ];
  var imageField = { key: "image_id", label: "系统镜像", type: "text", required: true, help: "填写上游镜像 ID" };
  var pid = productIdOf(ctx);
  if (pid) {
    try {
      var images = imageOptions(ctx, pid);
      if (images.length) {
        var options = [];
        for (var i = 0; i < images.length; i++) options.push({ value: images[i].value, label: images[i].label });
        imageField = { key: "image_id", label: "系统镜像", type: "select", required: true, options: options };
      }
    } catch (e) {
      log.warn("获取上游镜像失败：" + errorMessage(e));
    }
  }
  actions.push({
    name: "reinstall",
    label: "重装系统",
    danger: true,
    confirm: "重装会清空系统盘数据，确定继续吗？",
    fields: [
      imageField,
      { key: "password", label: "登录密码", type: "password", required: true },
      { key: "port", label: "远程端口", type: "number", default: "22" }
    ]
  });
  return actions;
}

function runAction(ctx, name, input) {
  var hostId = hostIdOf(ctx);
  if (!hostId) return failed("invalid_params", "缺少上游主机 ID", false);
  if (!ACTION_LABELS[name]) return failed("unsupported", "不支持的操作：" + name, false);
  input = input || {};
  var params = {};
  if (name === "reset_password") {
    if (!str(input.password)) return failed("invalid_params", "请填写新密码", false);
    params.password = str(input.password);
  } else if (name === "reinstall") {
    if (!str(input.image_id)) return failed("invalid_params", "请选择系统镜像", false);
    params.image_id = str(input.image_id);
    if (str(input.password)) params.password = str(input.password);
    params.port = num(input.port) || 22;
  }
  try {
    var resp = api(ctx, "POST", "/console/v1/remf_cloud/" + hostId + "/" + name, params);
    if (resp.status !== 200) return rejected(resp, ACTION_LABELS[name] + "失败");
    var extra = {};
    if (params.password) extra.secrets = { password: params.password };
    if (name === "reinstall") {
      try {
        extra.fields = hostInfo(ctx, hostId, null).fields;
      } catch (e2) {
        log.warn("刷新实例信息失败：" + errorMessage(e2));
      }
    }
    return succeeded(extra);
  } catch (e) {
    return unknownFrom(e);
  }
}

// 实例操作为同步接口，只有结果未知时才会查询：按电源状态或实例详情确认
function actionQuery(ctx) {
  var op = opInfo(ctx);
  var name = str(op.action);
  var input = op.input || {};
  var hostId = hostIdOf(ctx);
  if (!hostId) return unknown("invalid_params", "缺少上游主机 ID");
  var label = ACTION_LABELS[name] || name;
  try {
    if (name === "reset_password" || name === "reinstall") {
      var detail = cloudDetail(ctx, hostId);
      var pwOk = !str(input.password) || str(detail.password) === str(input.password);
      var imgOk = name !== "reinstall" || str(detail.image && detail.image.id) === str(input.image_id);
      if (pwOk && imgOk) return succeeded(str(input.password) ? { secrets: { password: str(input.password) } } : undefined);
      return unknown("upstream_error", "未能确认" + label + "结果，请到上游核对");
    }
    if (ACTION_LABELS[name]) {
      var resp = api(ctx, "GET", "/console/v1/mf_cloud/" + hostId + "/status");
      var power = str(resp.data && resp.data.status);
      var want = name === "off" || name === "hard_off" ? "off" : "on";
      if (power === want) return succeeded();
      if (/ing$|operating|wait|pending/.test(power)) return pending(10);
      return unknown("upstream_error", "未能确认" + label + "结果（当前电源状态：" + (power || "未知") + "）");
    }
    return unknown("unsupported", "不支持的操作：" + name);
  } catch (e) {
    return unknownFrom(e);
  }
}

function console(ctx) {
  var hostId = hostIdOf(ctx);
  if (!hostId) throw new Error("缺少上游主机 ID");
  var resp = api(ctx, "POST", "/console/v1/remf_cloud/" + hostId + "/vnc?more=1", {});
  var u = str(resp.data && resp.data.url);
  if (resp.status !== 200 || !u) throw new Error("获取控制台地址失败：" + (resp.msg || "上游未返回地址"));
  if (!/^https?:\/\//i.test(u)) u = baseURL(ctx) + (u.charAt(0) === "/" ? "" : "/") + u;
  return { type: "url", url: u };
}

// ---------- 入口 ----------

function fetchBalance(ctx) {
  var resp = api(ctx, "GET", "/console/v1/credit");
  if (resp.status !== 200 || !resp.data) throw upstreamError(classify(resp), "查询上游余额失败：" + resp.msg);
  return toCents(resp.data.credit);
}

function testConnection(ctx) {
  try {
    novaix.cache.delete(tokenKey(ctx));
    login(ctx);
    var balance = fetchBalance(ctx);
    return { ok: true, message: "连接成功，账户余额 ¥" + yuan(balance), balance: balance };
  } catch (e) {
    return { ok: false, message: errorMessage(e) };
  }
}

function getBalance(ctx) {
  return { balance: fetchBalance(ctx) };
}

function create(ctx) {
  return provision(ctx, "create");
}

function lookup(ctx) {
  return provision(ctx, "lookup");
}

function renew(ctx) {
  return renewFlow(ctx, false);
}

function query(ctx) {
  var type = str(opInfo(ctx).type);
  switch (type) {
    case "create":
      return provision(ctx, "query");
    case "renew":
      return renewFlow(ctx, true);
    case "suspend":
      return statusQuery(ctx, "Suspended", "暂停");
    case "unsuspend":
      return statusQuery(ctx, "Active", "解除暂停");
    case "terminate":
      return terminateQuery(ctx);
    case "action":
      return actionQuery(ctx);
  }
  return unknown("invalid_params", "不支持查询的操作类型：" + type);
}

function getService(ctx) {
  var hostId = hostIdOf(ctx);
  if (!hostId) return { status: "unknown", message: "缺少上游主机 ID" };
  var host = getHost(ctx, hostId);
  if (!host) return { status: "terminated", message: "上游未找到该主机" };
  var st = str(host.status);
  var mapping = { Active: "active", Pending: "pending", Unpaid: "pending", Suspended: "suspended", Deleted: "terminated", Cancelled: "terminated" };
  var out = { status: mapping[st] || "unknown", expire_at: dueOf(host), data: { upstream_status: st } };
  if (!mapping[st]) out.message = "上游主机状态：" + st;
  if (st === "Active" || st === "Suspended") {
    var info = hostInfo(ctx, hostId, host);
    out.fields = info.fields;
    if (info.secrets) out.secrets = info.secrets;
  }
  return out;
}
