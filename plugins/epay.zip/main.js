// 易支付插件 — 兼容彩虹易支付 / ZPAY 等通用规范
// 支持页面跳转 (jump) 和 API 出码 (mapi) 两种模式

/**
 * MD5 签名：参数按 key ASCII 升序排序（排除 sign、sign_type 和空值），
 * 拼接为 a=b&c=d，末尾直接追加密钥（不加 &），取 MD5 小写
 */
function epaySign(params) {
  var keys = [];
  for (var k in params) {
    if (k === "sign" || k === "sign_type" || !params[k]) continue;
    keys.push(k);
  }
  keys.sort();

  var parts = [];
  for (var i = 0; i < keys.length; i++) {
    parts.push(keys[i] + "=" + params[keys[i]]);
  }
  return crypto.md5(parts.join("&") + config.secret_key);
}

function buildQuery(params) {
  var keys = [];
  for (var k in params) {
    if (params[k] !== undefined && params[k] !== null && params[k] !== "") {
      keys.push(k);
    }
  }
  keys.sort();
  var parts = [];
  for (var i = 0; i < keys.length; i++) {
    parts.push(url.encode(keys[i]) + "=" + url.encode(String(params[keys[i]])));
  }
  return parts.join("&");
}

var typeLabels = {
  "alipay": "支付宝",
  "wxpay": "微信支付",
  "qqpay": "QQ 钱包",
  "bank": "网银支付",
  "jdpay": "京东支付",
  "paypal": "PayPal",
  "usdt": "USDT"
};

function parseTypes() {
  if (!config.type) return [];
  try { return JSON.parse(config.type); } catch (e) { return []; }
}

function getMethods() {
  var types = parseTypes();
  if (types.length <= 1) return null;

  var methods = [];
  for (var i = 0; i < types.length; i++) {
    if (typeof types[i] !== "string") continue;
    var t = types[i].trim();
    if (t) {
      methods.push({ name: t, label: typeLabels[t] || t });
    }
  }
  return methods.length > 0 ? methods : null;
}

function createPayment(req) {
  var apiUrl = config.api_url.replace(/\/+$/, "");
  var mode = config.mode || "jump";

  var params = {
    pid: config.pid,
    out_trade_no: req.orderNo,
    notify_url: req.notifyURL,
    return_url: req.returnURL,
    name: req.subject,
    money: (req.amount / 100).toFixed(2)
  };

  // 优先使用用户选择的支付方式，否则回退到管理员配置的第一个
  var payType = req.method;
  if (!payType) {
    var types = parseTypes();
    if (types.length > 0) payType = types[0];
  }
  if (payType) {
    params.type = payType;
  }

  if (config.extra_params) {
    try {
      var extra = JSON.parse(config.extra_params);
      for (var ek in extra) {
        if (extra[ek] !== undefined && extra[ek] !== null && extra[ek] !== "") {
          if (params[ek] !== undefined) {
            log.warn("额外参数忽略保留字段: " + ek);
            continue;
          }
          params[ek] = extra[ek];
        }
      }
    } catch (e) {
      log.warn("额外参数解析失败: " + e.message);
    }
  }
  if (mode === "mapi" && req.clientIP) {
    params.clientip = req.clientIP;
  }

  params.sign = epaySign(params);
  params.sign_type = "MD5";

  if (mode === "mapi") {
    return createPaymentMAPI(apiUrl, params);
  }

  return {
    payURL: apiUrl + "/submit.php?" + buildQuery(params),
    tradeNo: "",
    qrCode: false
  };
}

function createPaymentMAPI(apiUrl, params) {
  var resp = http.request("POST", apiUrl + "/mapi.php", {
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: buildQuery(params),
    timeout: 15
  });

  if (resp.status !== 200) {
    throw new Error("易支付 MAPI 接口返回异常状态码 " + resp.status);
  }

  var data = JSON.parse(resp.body);
  var code = parseInt(data.code);
  if (code !== 1 && code !== 200) {
    throw new Error("易支付创建订单失败: " + (data.msg || "未知错误"));
  }

  var payURL = "";
  var isQRCode = false;

  if (data.qrcode) {
    payURL = data.qrcode;
    isQRCode = true;
  } else if (data.payurl) {
    payURL = data.payurl;
  } else if (data.urlscheme) {
    payURL = data.urlscheme;
  } else {
    throw new Error("易支付 MAPI 未返回支付链接");
  }

  return {
    payURL: payURL,
    tradeNo: data.trade_no || "",
    qrCode: isQRCode
  };
}

function handleCallback(req) {
  // 易支付回调支持 GET/POST，参数在 query 或 body 中
  var params = {};

  // 合并 query 参数
  if (req.query) {
    for (var k in req.query) {
      params[k] = req.query[k];
    }
  }

  // 如果有 body（POST form），解析并合并
  // decodeURIComponent 不处理 '+'，需要先替换为 %20
  if (req.body && req.method === "POST") {
    var pairs = req.body.split("&");
    for (var i = 0; i < pairs.length; i++) {
      var kv = pairs[i].split("=");
      if (kv.length >= 2) {
        var key = decodeURIComponent(kv[0].replace(/\+/g, "%20"));
        var val = decodeURIComponent(kv.slice(1).join("=").replace(/\+/g, "%20"));
        params[key] = val;
      }
    }
  }

  var gotSign = params.sign || "";
  if (!gotSign) {
    throw new Error("易支付回调缺少签名");
  }

  var expectSign = epaySign(params);
  if (gotSign.toLowerCase() !== expectSign.toLowerCase()) {
    throw new Error("易支付回调签名验证失败");
  }

  if (params.pid && params.pid !== config.pid) {
    throw new Error("易支付回调商户号不匹配");
  }

  var outTradeNo = params.out_trade_no || "";
  if (!outTradeNo) {
    throw new Error("易支付回调缺少商户订单号");
  }

  var amountCents = 0;
  if (params.money) {
    amountCents = Math.round(parseFloat(params.money) * 100);
  }

  log.info("收到易支付回调: out_trade_no=" + outTradeNo + " trade_status=" + (params.trade_status || ""));

  return {
    orderNo: outTradeNo,
    tradeNo: params.trade_no || "",
    amount: amountCents,
    currency: "CNY",
    success: params.trade_status === "TRADE_SUCCESS",
    rawData: req.body || JSON.stringify(params)
  };
}
