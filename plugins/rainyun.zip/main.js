// 雨云云服务器（RCS）供应商插件：请求头 X-Api-Key 鉴权，JSON 请求体，成功响应为 {code: 200, data}。
// 创建接口没有名称/备注字段：创建前把现有实例 ID 列表写入检查点，创建后给实例打上本地引用标签，
// 结果未知时对比实例列表的新增项并核对标签（或套餐、系统与创建时间）反查。

var PAGE_SIZE = 20;
var CACHE_TTL = 300;
var DEFAULT_URL = "https://api.v2.rainyun.com";
var DURATIONS = {1: true, 3: true, 6: true, 12: true};
var DEFAULT_DURATIONS = {monthly: 1, quarterly: 3, yearly: 12};
var BUSY = {creating: true, booting: true, installing: true, reinstalling: true};
var STATUS_MAP = {running: "active", booting: "active", stopping: "active", stopped: "active", rebooting: "active", creating: "pending", installing: "pending", reinstalling: "pending", banned: "suspended", expired: "suspended"};
var REGION_NAMES = {"cn-hk1": "香港", "cn-hk2": "香港二区", "cn-sq1": "宿迁", "cn-nb1": "宁波", "cn-cq1": "重庆", "us-la1": "洛杉矶", "jp-tk1": "东京"};
var CODE_ERRORS = {
  10002: ["invalid_params", "参数无效"],
  10005: ["not_found", "无权限或产品已释放"],
  30023: ["out_of_stock", "套餐库存不足"],
  30039: ["auth", "API 密钥错误"],
  30043: ["auth", "需要二次验证，请在雨云控制台关闭 API 二次验证"],
  70003: ["insufficient_balance", "雨云账户余额不足"],
  70006: ["auth", "雨云账号需要实名认证"],
  70010: ["unsupported", "不允许释放"],
  70021: ["upstream_error", "产品已过期"],
  70026: ["invalid_params", "当前状态无法执行该操作"]
};

// ---------- 基础 ----------

function baseURL() {
  var u = String(config.url || DEFAULT_URL).trim().replace(/\/+$/, "");
  if (!/^https?:\/\//i.test(u)) throw new Error("接口地址无效");
  return u;
}

// rc 调用雨云接口：网络错误或响应无法解析时抛异常；HTTP 非 200 时同样解析 body 中的 code/message
function rc(method, path, body, timeout) {
  var opts = {headers: {"X-Api-Key": String(config.api_key || ""), "Accept": "application/json"}, timeout: timeout || 30};
  if (body !== undefined) {
    opts.headers["Content-Type"] = "application/json";
    opts.body = JSON.stringify(body);
  }
  var resp = http.request(method, baseURL() + path, opts);
  var data = null;
  try { data = JSON.parse(resp.body); } catch (e) { data = null; }
  if (!data || typeof data !== "object") throw new Error("雨云返回无法解析的响应（HTTP " + resp.status + "）");
  var code = Number(data.code);
  return {ok: code === 200, code: code, http: resp.status, data: data.data, message: String(data.message || data.msg || "")};
}

function tryRc(method, path, body, timeout) {
  try { return rc(method, path, body, timeout); }
  catch (e) { return {error: errText(e)}; }
}

function errText(e) { return String((e && e.message) || e); }

function codeOf(r) {
  if (CODE_ERRORS[r.code]) return CODE_ERRORS[r.code][0];
  if (r.http === 401 || r.http === 403) return "auth";
  if (r.http === 429) return "rate_limited";
  return "upstream_error";
}

function describe(r) {
  var known = CODE_ERRORS[r.code] ? CODE_ERRORS[r.code][1] : "";
  var parts = [];
  if (known) parts.push(known);
  if (r.message && r.message !== known) parts.push(r.message);
  return (parts.join("：") || "未知错误") + "（code " + r.code + "）";
}

function failed(code, message, retryable) { return {status: "failed", error: {code: code, message: message, retryable: !!retryable}}; }
function unknown(message) { return {status: "unknown", error: {code: "upstream_error", message: message}}; }
function pending(message, retryAfter, extra) {
  if (message) novaix.note(message);
  return merge({status: "pending", retry_after: retryAfter || 15}, extra || {});
}
function merge(target, src) {
  for (var k in src) if (src[k] !== undefined) target[k] = src[k];
  return target;
}

function checkpointOf(ctx) {
  var cp = ctx.operation && ctx.operation.checkpoint;
  return cp && typeof cp === "object" ? merge({}, cp) : {};
}
function save(cp) { novaix.checkpoint(cp); return cp; }

function toInt(v) {
  var s = String(v === undefined || v === null ? "" : v).trim();
  return /^[0-9]+$/.test(s) ? parseInt(s, 10) : 0;
}

function cents(yuan) {
  var n = Number(yuan);
  return isFinite(n) ? Math.round(n * 100) : undefined;
}

function nowSec() { return Math.floor(Date.now() / 1000); }

function instanceID(ctx) {
  var id = toInt(ctx.service && ctx.service.remote_id);
  if (!id) throw new Error("服务尚未关联雨云实例");
  return id;
}

function durationOf(ctx) {
  var d = toInt(ctx.service.cycle_param) || DEFAULT_DURATIONS[ctx.service.billing_cycle] || 1;
  return DURATIONS[d] ? d : 0;
}

// ---------- 目录（全量缓存） ----------

function plans() {
  var cached = novaix.cache.get("plans");
  if (cached) return cached;
  var r = rc("GET", "/product/rcs/plans?is_rgpu=false", undefined, 60);
  if (!r.ok) throw new Error("获取雨云套餐失败：" + describe(r));
  var items = (Array.isArray(r.data) ? r.data : []).map(function (p) {
    return {
      id: Number(p.id), region: String(p.region || ""), name: String(p.chinese || p.name || ("套餐 #" + p.id)),
      selling: p.is_selling === true || p.is_selling === 1 || p.is_selling === "true",
      price: Number(p.price), cpu: Number(p.cpu), memory: Number(p.memory), net_out: Number(p.net_out),
      stock: p.available_stock === undefined ? -1 : Number(p.available_stock)
    };
  });
  novaix.cache.set("plans", items, CACHE_TTL);
  return items;
}

function templates() {
  var cached = novaix.cache.get("os_templates");
  if (cached) return cached;
  var r = rc("GET", "/product/rcs/os-templates", undefined, 60);
  if (!r.ok) throw new Error("获取雨云系统模板失败：" + describe(r));
  var items = (Array.isArray(r.data) ? r.data : []).map(function (t) {
    return {
      id: Number(t.id), region: String(t.region || ""), name: String(t.chinese_name || t.name || ("系统 #" + t.id)),
      type: String(t.os_type || ""), ok: (t.is_available === true || t.is_available === 1) && t.sync_status === "synced"
    };
  });
  novaix.cache.set("os_templates", items, CACHE_TTL);
  return items;
}

function findPlan(id) {
  id = toInt(id);
  var all = plans();
  for (var i = 0; i < all.length; i++) if (all[i].id === id) return all[i];
  return null;
}

function regionLabel(code) { return REGION_NAMES[code] || code; }

function osOptions(region) {
  return templates().filter(function (t) { return t.ok && t.region === region; }).map(function (t) {
    return {value: String(t.id), label: t.name, description: regionLabel(t.region) + (t.type ? " · " + t.type : "")};
  });
}

function paginate(items, page, keyword) {
  var kw = String(keyword || "").trim().toLowerCase();
  if (kw) {
    items = items.filter(function (it) {
      return (it.value + " " + it.label + " " + (it.description || "")).toLowerCase().indexOf(kw) !== -1;
    });
  }
  var p = Math.max(1, parseInt(page, 10) || 1);
  var start = (p - 1) * PAGE_SIZE;
  return {items: items.slice(start, start + PAGE_SIZE), has_more: start + PAGE_SIZE < items.length};
}

function getOptions(ctx, fieldKey, values, opts) {
  opts = opts || {};
  values = values || {};
  var items = [];
  if (fieldKey === "plan_id") {
    items = plans().filter(function (p) { return p.selling; }).map(function (p) {
      var mem = p.memory >= 1024 ? (Math.round(p.memory / 102.4) / 10) + " GB" : p.memory + " MB";
      var desc = [p.cpu + " 核", mem, "上行 " + p.net_out + " Mbps", "¥" + p.price + "/月"];
      if (p.stock === 0) desc.push("缺货");
      return {value: String(p.id), label: "[" + regionLabel(p.region) + "] " + p.name, description: desc.join(" · ")};
    });
  } else if (fieldKey === "os_id") {
    var plan = values.plan_id ? findPlan(values.plan_id) : null;
    if (plan) items = osOptions(plan.region);
  }
  return paginate(items, opts.page, opts.keyword);
}

// quotePrice 询价（元 → 分），失败时返回 undefined，仅用于记录成本
function quotePrice(query) {
  try {
    var r = rc("GET", "/product/rcs/price?" + query);
    if (!r.ok) return undefined;
    var v = r.data;
    if (v && typeof v === "object") v = v.price !== undefined ? v.price : (v.Price !== undefined ? v.Price : v.total_price);
    return cents(v);
  } catch (e) {
    return undefined;
  }
}

// ---------- 实例 ----------

function idList() {
  var r = rc("GET", "/product/id_list?product_type=rcs");
  if (!r.ok) throw new Error("获取雨云实例列表失败：" + describe(r));
  var ids = (r.data && Array.isArray(r.data.rcs)) ? r.data.rcs : [];
  return ids.map(Number).filter(function (n) { return n > 0; });
}

// detail 查询实例详情：已释放（10005）返回 {gone: true}，其他失败抛异常
function detail(id) {
  var r = rc("GET", "/product/rcs/" + id + "/");
  if (r.code === 10005) return {gone: true};
  if (!r.ok) throw new Error("查询雨云实例失败：" + describe(r));
  var d = r.data || {};
  return {inst: d.Data || d, nat: Array.isArray(d.NatList) ? d.NatList : []};
}

function isWindows(inst) { return /windows/i.test(String(inst.OsName || "")); }

function fieldsOf(d) {
  var inst = d.inst;
  var fields = [];
  var main = String(inst.MainIPv4 || "");
  var nat = !main || main === "-";
  var ip = nat ? String(inst.NatPublicIP || "") : main;
  var inner = isWindows(inst) ? 3389 : 22;
  var port = nat ? 0 : inner;
  if (nat) {
    d.nat.forEach(function (n) { if (Number(n.PortIn) === inner && !port) port = Number(n.PortOut); });
  }
  if (ip) fields.push({key: "ip", label: "IP 地址", value: ip, copyable: true});
  if (inst.MainIPv6) fields.push({key: "ipv6", label: "IPv6 地址", value: String(inst.MainIPv6), copyable: true});
  if (port) fields.push({key: "port", label: isWindows(inst) ? "远程桌面端口" : "SSH 端口", value: String(port), copyable: true});
  fields.push({key: "username", label: "用户名", value: isWindows(inst) ? "Administrator" : "root", copyable: true});
  if (inst.OsName) fields.push({key: "os", label: "操作系统", value: String(inst.OsName)});
  if (nat && d.nat.length) {
    var maps = d.nat.map(function (n) { return n.PortOut + " → " + n.PortIn; }).join(", ");
    fields.push({key: "nat_ports", label: "端口映射", value: maps});
  }
  if (inst.Region) fields.push({key: "region", label: "地域", value: regionLabel(String(inst.Region))});
  return fields;
}

function tagInstance(ctx, cp) {
  if (cp.tagged) return;
  var r = tryRc("PATCH", "/product/rcs/" + cp.instance_id + "/tag", {tag_name: ctx.service.reference});
  if (r.error || !r.ok) {
    novaix.note("为实例 #" + cp.instance_id + " 设置标签失败：" + (r.error || describe(r)));
    return;
  }
  cp.tagged = true;
  save(cp);
}

// advance 等待实例创建完成
function advance(ctx, cp) {
  tagInstance(ctx, cp);
  var progress = {remote_id: String(cp.instance_id), data: {plan_id: cp.plan_id, os_id: cp.os_id}};
  var d;
  try { d = detail(cp.instance_id); }
  catch (e) { return pending("查询实例失败，稍后重试：" + errText(e), 15, progress); }
  if (d.gone) return merge(unknown("雨云实例 #" + cp.instance_id + " 不存在或已释放，请人工核对"), progress);
  var inst = d.inst;
  if (BUSY[inst.Status]) return pending("实例创建中（" + inst.Status + "）", 15, progress);
  return merge({
    status: "succeeded", fields: fieldsOf(d), secrets: inst.DefaultPass ? {password: String(inst.DefaultPass)} : undefined,
    expire_at: Number(inst.ExpDate) || undefined, cost: cp.price
  }, progress);
}

// ---------- 开通 ----------

function create(ctx) {
  var cp = checkpointOf(ctx);
  if (cp.instance_id) return advance(ctx, cp);
  if (!/^[0-9a-f]{32}$/.test(String(ctx.service.reference || ""))) return failed("invalid_params", "服务缺少有效的幂等引用");
  var product = ctx.product || {};
  var planId = toInt(product.plan_id), osId = toInt(product.os_id), duration = durationOf(ctx);
  var eip = toInt(product.with_eip_num);
  if (!planId || !osId) return failed("invalid_params", "商品未配置套餐或系统模板");
  if (!duration) return failed("invalid_params", "上游时长只能为 1、3、6、12 个月");

  // 记录现有实例与提交时间，供结果未知时反查
  var ids = idList();
  var price = quotePrice("scene=create&plan_id=" + planId + "&duration=" + duration);
  cp = {stage: "ordering", started_at: nowSec(), plan_id: planId, os_id: osId, price: price,
    before_max: ids.length ? Math.max.apply(null, ids) : 0};
  if (ids.length <= 1500) cp.before_ids = ids;
  save(cp);

  var r = tryRc("POST", "/product/rcs/", {plan_id: planId, os_id: osId, duration: duration, with_eip_num: eip, try: false}, 60);
  if (r.error) return unknown("提交雨云创建请求时连接异常：" + r.error);
  if (!r.ok) {
    save({});
    return failed(codeOf(r), "雨云创建实例失败：" + describe(r), false);
  }
  var data = r.data || {};
  var id = toInt(data.ID || data.id || (data.Data && data.Data.ID));
  if (!id) return unknown("雨云已受理创建但未返回实例 ID");
  cp.instance_id = id;
  cp.stage = "created";
  save(cp);
  novaix.note("雨云实例 #" + id + " 已创建");
  return advance(ctx, cp);
}

function lookup(ctx) {
  var cp = checkpointOf(ctx);
  if (cp.instance_id) return advance(ctx, cp);
  if (!cp.stage) return failed("not_found", "尚未向雨云提交创建请求");
  var ref = String(ctx.service.reference);
  var before = Array.isArray(cp.before_ids) ? cp.before_ids : null;
  var candidates = idList().filter(function (id) {
    return before ? before.indexOf(id) === -1 : id > Number(cp.before_max || 0);
  }).sort(function (a, b) { return b - a; }).slice(0, 20);
  var tagged = null, similar = [];
  for (var i = 0; i < candidates.length && !tagged; i++) {
    var d = detail(candidates[i]);
    if (d.gone) continue;
    var inst = d.inst;
    if (String(inst.Tag || "") === ref) tagged = candidates[i];
    else if (!inst.Tag && Number(inst.PlanID) === cp.plan_id && Number(inst.OsID) === cp.os_id &&
      Number(inst.CreateDate || 0) >= Number(cp.started_at || 0) - 300) similar.push(candidates[i]);
  }
  var found = tagged;
  if (!found && similar.length > 1) return unknown("找到多个可能对应的雨云实例（" + similar.join(", ") + "），请人工核对");
  if (!found) found = similar[0];
  if (!found) return failed("not_found", "雨云未找到本次创建的实例");
  cp.instance_id = found;
  cp.stage = "created";
  cp.tagged = !!tagged;
  save(cp);
  novaix.note("反查到雨云实例 #" + found);
  return advance(ctx, cp);
}

// ---------- 续费 ----------

function renew(ctx) {
  var id = instanceID(ctx);
  var cp = checkpointOf(ctx);
  if (cp.stage) return confirmRenew(id, cp);
  var duration = durationOf(ctx);
  if (!duration) return failed("invalid_params", "上游时长只能为 1、3、6、12 个月");
  var d = detail(id);
  if (d.gone) return failed("not_found", "雨云实例 #" + id + " 不存在或已释放");
  cp = {old_exp: Number(d.inst.ExpDate || 0), price: quotePrice("scene=renew&product_id=" + id + "&duration=" + duration), stage: "renewing"};
  save(cp);
  var r = tryRc("POST", "/product/rcs/" + id + "/renew/", {duration: duration}, 60);
  if (r.error) return unknown("提交雨云续费请求时连接异常：" + r.error);
  if (!r.ok) {
    save({});
    return failed(codeOf(r), "雨云续费失败：" + describe(r), false);
  }
  cp.stage = "submitted";
  save(cp);
  return confirmRenew(id, cp);
}

// confirmRenew 到期时间前移才算续费成功
function confirmRenew(id, cp) {
  var d = detail(id);
  if (d.gone) return unknown("续费后查询实例失败：实例不存在");
  var exp = Number(d.inst.ExpDate || 0);
  if (exp > Number(cp.old_exp || 0)) return {status: "succeeded", expire_at: exp, cost: cp.price, fields: fieldsOf(d)};
  if (cp.stage === "submitted") return pending("续费已提交，等待到期时间更新", 10);
  return unknown("续费请求结果未知，上游到期时间未变化");
}

// ---------- 电源 / 暂停 / 恢复 ----------

// power 执行开关机；先检查当前状态，已处于目标状态直接成功（可安全重复调用）
function power(ctx, action, target) {
  var id = instanceID(ctx);
  var d = detail(id);
  if (d.gone) return failed("not_found", "雨云实例 #" + id + " 不存在或已释放");
  if (target && d.inst.Status === target) return {status: "succeeded"};
  var r = tryRc("POST", "/product/rcs/" + id + "/" + action, {}, 30);
  if (r.error) return unknown("调用雨云 " + action + " 时连接异常：" + r.error);
  if (r.ok) return {status: "succeeded"};
  if (target) {
    var again = detail(id);
    if (!again.gone && again.inst.Status === target) return {status: "succeeded"};
  }
  return failed(codeOf(r), "雨云 " + action + " 失败：" + describe(r), false);
}

function suspend(ctx) { return power(ctx, "stop", "stopped"); }
function unsuspend(ctx) { return power(ctx, "start", "running"); }

// ---------- 释放 ----------

function confirmGone(id) {
  var d = detail(id);
  if (d.gone) return {status: "succeeded"};
  return pending("已提交释放，等待雨云删除实例", 15);
}

function terminate(ctx) {
  var id = instanceID(ctx);
  var d = detail(id);
  if (d.gone) return {status: "succeeded"};
  var inst = d.inst;
  var expired = Number(inst.ExpDate || 0) <= nowSec();
  var r;
  if (!expired && (inst.UnsubscribeAble === true || inst.UnsubscribeAble === 1)) {
    r = tryRc("POST", "/expense/unsubscribe", {product_id: id, product_type: "rcs", suggestion: ""}, 60);
    if (r.error) return unknown("提交雨云退订请求时连接异常：" + r.error);
    if (r.ok || r.code === 10005) return confirmGone(id);
    novaix.note("雨云退订失败：" + describe(r) + "，尝试直接释放");
  }
  r = tryRc("POST", "/product/rcs/" + id + "/free", {}, 60);
  if (r.error) return unknown("提交雨云释放请求时连接异常：" + r.error);
  if (r.ok || r.code === 10005) return confirmGone(id);
  if (r.code === 70010) return failed("unsupported", "雨云不允许释放该实例（未到期且不可退订），请到期后再试或在雨云控制台处理", false);
  return failed(codeOf(r), "雨云释放实例失败：" + describe(r), false);
}

// ---------- 自定义操作 ----------

function serviceOSOptions(ctx) {
  try {
    var plan = findPlan((ctx.product || {}).plan_id);
    return plan ? osOptions(plan.region) : [];
  } catch (e) {
    return [];
  }
}

function getActions(ctx) {
  var actions = [
    {name: "start", label: "开机"},
    {name: "stop", label: "关机", confirm: "确定要关机吗？"},
    {name: "reboot", label: "重启", confirm: "确定要重启吗？"},
    {name: "reset_password", label: "重置密码", confirm: "确定要重置登录密码吗？",
      fields: [{key: "password", label: "新密码", type: "password", required: true, validation: {min_length: 8, message: "密码至少 8 位"}}]}
  ];
  var opts = serviceOSOptions(ctx);
  if (opts.length) {
    actions.push({name: "reinstall", label: "重装系统", danger: true, confirm: "重装将清空实例上的全部数据，确定继续吗？",
      fields: [{key: "os_id", label: "操作系统", type: "select", required: true, options: opts.map(function (o) { return {value: o.value, label: o.label}; })}]});
  }
  return actions;
}

function runAction(ctx, name, input) {
  input = input || {};
  var id = instanceID(ctx);
  var r;
  switch (name) {
    case "start": return power(ctx, "start", "running");
    case "stop": return power(ctx, "stop", "stopped");
    case "reboot": return power(ctx, "reboot", "");
    case "reset_password": {
      var pw = String(input.password || "");
      if (pw.length < 8) return failed("invalid_params", "密码至少 8 位");
      r = tryRc("POST", "/product/rcs/" + id + "/reset-password", {password: pw}, 60);
      if (r.error) return unknown("调用雨云重置密码时连接异常：" + r.error);
      if (!r.ok) return failed(codeOf(r), "雨云重置密码失败：" + describe(r), false);
      return {status: "succeeded", secrets: {password: pw}};
    }
    case "reinstall": {
      var cp = checkpointOf(ctx);
      if (cp.stage) return confirmReinstall(id, cp);
      var osId = toInt(input.os_id);
      var allowed = serviceOSOptions(ctx).some(function (o) { return o.value === String(osId); });
      if (!osId || !allowed) return failed("invalid_params", "所选系统模板不可用");
      cp = save({stage: "reinstalling", os_id: osId});
      r = tryRc("POST", "/product/rcs/" + id + "/changeos", {os_id: osId}, 60);
      if (r.error) return unknown("提交雨云重装请求时连接异常：" + r.error);
      if (!r.ok) {
        save({});
        return failed(codeOf(r), "雨云重装失败：" + describe(r), false);
      }
      cp.stage = "submitted";
      save(cp);
      return pending("重装已提交，等待系统安装完成", 15);
    }
  }
  return failed("invalid_params", "不支持的操作：" + name);
}

// confirmReinstall 系统模板已切换且实例不处于安装中即视为完成，新密码从详情读取
function confirmReinstall(id, cp) {
  var d = detail(id);
  if (d.gone) return unknown("重装后查询实例失败：实例不存在");
  var inst = d.inst;
  if (BUSY[inst.Status]) return pending("系统重装中（" + inst.Status + "）", 15);
  if (Number(inst.OsID) === Number(cp.os_id)) {
    return {status: "succeeded", fields: fieldsOf(d), secrets: inst.DefaultPass ? {password: String(inst.DefaultPass)} : undefined};
  }
  if (cp.stage === "submitted") return pending("等待雨云开始重装", 15);
  return unknown("重装请求结果未知，请到雨云控制台核对");
}

// ---------- 查询 ----------

function query(ctx) {
  var op = ctx.operation || {};
  var cp = checkpointOf(ctx);
  switch (op.type) {
    case "create":
      if (!cp.instance_id && ctx.service.remote_id) cp = save(merge(cp, {instance_id: toInt(ctx.service.remote_id), stage: "created"}));
      return cp.instance_id ? advance(ctx, cp) : lookup(ctx);
    case "renew":
      return cp.stage ? confirmRenew(instanceID(ctx), cp) : renew(ctx);
    case "suspend":
      return suspend(ctx);
    case "unsuspend":
      return unsuspend(ctx);
    case "terminate":
      return terminate(ctx);
    case "action":
      return queryAction(ctx, op.action, op.input || {}, cp);
  }
  return unknown("不支持查询的操作类型：" + op.type);
}

function queryAction(ctx, name, input, cp) {
  var id = instanceID(ctx);
  switch (name) {
    case "start":
    case "stop":
    case "reset_password":
      return runAction(ctx, name, input);
    case "reboot": {
      var d = detail(id);
      if (d.gone) return failed("not_found", "雨云实例不存在或已释放");
      if (d.inst.Status === "running") return {status: "succeeded"};
      if (BUSY[d.inst.Status] || d.inst.Status === "rebooting") return pending("实例重启中", 10);
      return unknown("无法确认重启结果，实例状态为 " + d.inst.Status);
    }
    case "reinstall":
      return cp.stage ? confirmReinstall(id, cp) : runAction(ctx, name, input);
  }
  return unknown("不支持查询的操作：" + name);
}

// ---------- 服务信息 / 余额 / 连接 / 控制台 ----------

function getService(ctx) {
  var id = instanceID(ctx);
  var d = detail(id);
  if (d.gone) return {status: "terminated", message: "雨云实例不存在或已释放"};
  var inst = d.inst;
  // 不回传 DefaultPass：用户重置密码后详情中的初始密码可能已过期
  return {status: STATUS_MAP[inst.Status] || "unknown", expire_at: Number(inst.ExpDate) || undefined, fields: fieldsOf(d),
    message: inst.Status && !STATUS_MAP[inst.Status] ? "雨云实例状态：" + inst.Status : ""};
}

function account() {
  var r = rc("GET", "/user/");
  if (!r.ok) throw new Error("查询雨云账号失败：" + describe(r));
  return r.data || {};
}

function testConnection(ctx) {
  try {
    var u = account();
    return {ok: true, message: "连接成功，雨云账号：" + (u.Name || u.ID || ""), balance: cents(u.Money) || 0};
  } catch (e) {
    return {ok: false, message: errText(e)};
  }
}

function getBalance(ctx) { return {balance: cents(account().Money) || 0}; }

function console(ctx) {
  var id = instanceID(ctx);
  var r = rc("GET", "/product/rcs/" + id + "/vnc?console_type=novnc");
  if (!r.ok) throw new Error("获取 VNC 失败：" + describe(r));
  var v = r.data || {};
  if (v.VNCProxyURL) return {type: "url", url: String(v.VNCProxyURL)};
  if (v.RequestURL) return {type: "form", action: String(v.RequestURL), method: "POST", fields: {pveauth: String(v.PVEAuth || ""), redurl: String(v.RedirectURL || "")}};
  throw new Error("雨云未返回 VNC 地址");
}
